<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
        
            $table->increments('id');
            $table->string('name');
            $table->string('email')->unique();
            $table->string('password', 60);
            $table->string('address');
            $table->string('contact_number');
            $table->string('alternate_contact_number');
            $table->string('country');
            $table->string('city');
            $table->string('pin');
            $table->string('fax');
            $table->string('image_path');
            $table->string('business_card');
            $table->date('dob');
            $table->string('national_id');
            $table->string('bank_name');
            $table->string('branch_name');
            $table->string('branch_address');
            $table->string('account_type');
            $table->string('account_number');
            $table->string('swift_code');
            $table->string('ifsc_code');
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::statement('SET FOREIGN_KEY_CHECKS = 0');
        Schema::drop('users');
        DB::statement('SET FOREIGN_KEY_CHECKS = 1');
    }
}
