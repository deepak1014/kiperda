<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateNewVendorTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('vendors', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->string('email')->unique();
            $table->integer('contact_number');
            $table->integer('mobile_number');
            $table->string('organization_name');
            $table->string('country');
            $table->string('city');
            $table->integer('pincode');
            $table->string('fax_telephone');
            $table->string('image');
            $table->string('vendor_code');
            $table->string('currency');
            $table->string('status');
            $table->string('kipg_associate_code');
            $table->string('preferred_vendor');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('vendors');
    }
}



