<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Trademarksubtype extends model
{
    protected $table="trademarksubtype";

    
}
