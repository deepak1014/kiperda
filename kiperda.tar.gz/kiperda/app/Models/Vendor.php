<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Vendor extends Model
{
   // protected $table="vendors";

    protected $fillable=['name','email', 'contact_number', 'mobile_number', 'organization_name', 'country', 'city', 'pincode', 'fax_telephone', 'image', 'vendor_code', 'currency', 'status', 'kipg_associate_code', 'preferred_vendor', 'created_at', 'updated_at'];


	public function vendor_bank_detail()
    {
        return $this->hasOne('App\Models\VendorBankDetail');
    }
    
     
}
