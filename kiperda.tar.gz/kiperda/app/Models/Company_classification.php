<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Company_classification extends Model
{

protected $table = "company_classifications";  
  
  //protected $fillable = ['company_id', 'address_line_1', 'address_line_2', 'country', 'city', 'pin', 'fax_telephone'];
  
  //protected $fillable = ['name', 'email'];
  
}
//namespace App\Models;
//
//use Illuminate\Database\Eloquent\Model;
//
//class Country extends Model
//{
//    protected $table = countries;
//}
//
//
//namespace App\Models;
//
//use Illuminate\Database\Eloquent\Model;
//
//class Document extends Model
//{
//    protected $fillable = [name, size, path, file_display, fk_client_id];
//
//    public function clients()
//    {
//        $this->belongsTo(Client::class, fk_client_id);
//    }
//}