<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Companie extends Model
{

  //protected $table = companies;  
  
  protected $fillable = ['name', 'email', 'contact_number', 'alternate_contact_number', 'website', 'logo_path', 'type', 'currency', 'is_group', 'group_id', 'status', 'credit_limit', 'created_at', 'updated_at'];
  
  //protected $fillable = ['name', 'email'];
  
}
//namespace App\Models;
//
//use Illuminate\Database\Eloquent\Model;
//
//class Country extends Model
//{
//    protected $table = countries;
//}
//
//
//namespace App\Models;
//
//use Illuminate\Database\Eloquent\Model;
//
//class Document extends Model
//{
//    protected $fillable = [name, size, path, file_display, fk_client_id];
//
//    public function clients()
//    {
//        $this->belongsTo(Client::class, fk_client_id);
//    }
//}