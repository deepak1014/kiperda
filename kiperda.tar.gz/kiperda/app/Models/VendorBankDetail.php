<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VendorBankDetail extends Model
{

	    protected $table="vendors_bank_details";
     
}
