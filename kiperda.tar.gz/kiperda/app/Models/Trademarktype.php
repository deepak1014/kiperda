<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Trademarktype extends model
{
    protected $table="trademarktype";

    public function trademarksubtype()
    {
        return $this->hasMany('App\Models\Trademarksubtype');
    }
}
