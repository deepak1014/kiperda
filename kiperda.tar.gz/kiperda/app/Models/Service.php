<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Service extends model
{
    protected $table="services";

    
}
