<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Vendors_Address extends Model
{
	protected $table="vendors_addresses";
   protected $fillable=['vendor_id','address'];
     
}
