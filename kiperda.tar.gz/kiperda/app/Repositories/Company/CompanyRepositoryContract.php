<?php
namespace App\Repositories\Company;

interface CompanyRepositoryContract
{

    public function find($id);
    
    public function listAllCompanies();

    public function getAllCompaniesCount();

    public function create($requestData);
    public function status($id);
   public function changestatus($id);

    public function update($id, $requestData);
}
