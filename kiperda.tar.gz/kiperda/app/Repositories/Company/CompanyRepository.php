<?php
namespace App\Repositories\Company;

use App\Models\Companie;
use App\Models\Company_classification;
use App\Models\Client;
use App\Models\Industry;
use App\Models\Invoices;
use App\Models\TaskTime;
use App\Models\Settings;
use App\Models\Role;
use App\Models\Companies_addresses;
use App\Models\Tasks;
use Illuminate\Support\Facades\Session;
use Illuminate\Http\Request;
use Gate;
use Datatables;
use Carbon;
use PHPZen\LaravelRbac\Traits\Rbac;

use Auth;
use Illuminate\Support\Facades\Input;

use App\Models\Department;
use DB;


class CompanyRepository implements CompanyRepositoryContract
{

    public function find($id)
    {
        return Companie::findOrFail($id);
    }
    
    public function listAllCompanies()
    {
        return Companie::pluck('name', 'id');
    }

    public function getAllCompaniesCount()
    {
        return Companie::all()->count();
    }
    
//    public function create($requestData)
//    {
//      print_r($requestData->all());
//     exit();
//        
//        Companie::create($requestData->all());
//        
//    }
    
    /**********************************develop by satya 18/11/2016************************************/
    /**********************************code for create company************************************/
    
    public function create($requestData)
    {
     $address = $requestData->address;
     $settings = Settings::first();
     $companyname = $settings->company;
     if ($requestData->hasFile('logo_path')) {
          if (!is_dir(public_path(). '/images/'. $companyname)) {
                mkdir(public_path(). '/images/'. $companyname, 0777, true);
            }
            $settings = Settings::findOrFail(1);
            $file =  $requestData->file('logo_path');
            $destinationPath = public_path(). '/images/'. $companyname;
            $filename = str_random(8) . '_' . $file->getClientOriginalName() ;
             $file->move($destinationPath, $filename);
            
            $input =  array_replace($requestData->all(), ['logo_path'=>"$filename"]);
        } else {
            $input =  array_replace($requestData->all());
        }

        $user = Companie::create($input);
        $user->save();
        $companyid=  DB::table('companies')->max('id');
          foreach($address as $value)
          {
            Companies_addresses::create([
          'company_id' => $companyid,
          'address_line_1' => $value
            ]);  
          }
        Session::flash('flash_message', 'User successfully added!'); //Snippet in Master.blade.php
        return $user;

    }
      public function show($requestData)
    {
    $settings = Settings::first();
   $companyname = $settings->company;
          
      }
      public function update($id, $requestData)
    {
  $settings = Settings::first();
   $companyname = $settings->company;
  $user = Companie::findorFail($id);    
  $address= $requestData->address;
  $client = Companies_addresses::findOrFail(1);
     foreach($address as $value) 
      {
       Companies_addresses::where('company_id', '=', $id)
      ->update(['address_line_1' => $value]);
      }

        if ($requestData->hasFile('logo_path')) {
            
            $settings = Settings::findOrFail(1);
            $companyname = $settings->company;
            $file =  $requestData->file('logo_path');

            $destinationPath = public_path(). '\\images\\'. $companyname;
             $filename = str_random(8) . '_' . $file->getClientOriginalName() ;
             $file->move($destinationPath, $filename);
           $input =  array_replace($requestData->all(), ['logo_path'=>"$filename"]);
            
        } else {

                $input =  array_replace($requestData->all());

        }

        $user->fill($input)->save();
         Session::flash('flash_message', 'User successfully updated!');

        return $user;
    }

    public function destroy($id)
    {
        if ($id == 1) {
            return Session()->flash('flash_message_warning', 'Not allowed to delete super admin');
        }
        try {
            $user = Companie::findorFail($id);
            $user->delete();
            Session()->flash('flash_message', 'User successfully deleted');
        } catch (\Illuminate\Database\QueryException $e) {
            Session()->flash('flash_message_warning', 'User can NOT have, leads, clients, or tasks assigned when deleted');
        }
    }
    public function status($id)
    {
$status = Companie::orderBy('id', 'asc')->where('id', $id)
                ->get();
     $statusvalue = $status[0]['status'];

        if($statusvalue==1)
        {
            $value=0;
        } else {
         $value=1;   
        }
      
     $value = Companie::orderBy('id', 'asc')
                ->where('id', $id)
                ->update(['status' => $value]);
      
      
    }
    public function changestatus($id)
    {
        if ($id == 1) {
            return Session()->flash('flash_message_warning', 'Not allowed to delete super admin');
        }
        try {
            $user = Companie::findorFail($id);
            $user->delete();
            Session()->flash('flash_message', 'User successfully deleted');
        } catch (\Illuminate\Database\QueryException $e) {
            Session()->flash('flash_message_warning', 'User can NOT have, leads, clients, or tasks assigned when deleted');
        }
    }
    
    
    
    
    
    
    
    
    
}
