<?php
namespace App\Repositories\Trademark;

interface TrademarkRepositoryContract
{
    
    public function listallcountries();

}
