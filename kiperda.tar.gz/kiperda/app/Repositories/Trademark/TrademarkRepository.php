<?php
namespace App\Repositories\Vendor;

use App\Models\Settings;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Illuminate\Http\Request;
use Gate;
use Datatables;
use Carbon;
use PHPZen\LaravelRbac\Traits\Rbac;
use App\Models\Role;
use Auth;
use Illuminate\Support\Facades\Input;
use App\Models\Department;
use App\Models\Vendors_Address;
use App\Models\Country;



class TrademarkRepository implements TrademarkRepositoryContract
{
 
    public function listallcountries()
    {
        return Country::pluck('country_name');

    }
     
     
 }

