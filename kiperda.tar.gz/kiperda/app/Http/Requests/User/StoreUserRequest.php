<?php

namespace App\Http\Requests\User;

use App\Http\Requests\Request;

class StoreUserRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return auth()->user()->can('user-create');
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        if(Request::get('user_type') == 5){
            return [
                'name' => 'required',
                'email' => 'required|email|unique:users,email',
                'address' => '',
                'contact_number' => 'numeric',
                'country' => 'required',
                'city' => 'required',
                'pin' => 'required',
                'fax' => 'required',
                'user_type' => 'required',
                'company_id' => 'required',
                'vendor_id' => 'required'
            ];
        }else if(Request::get('user_type') == 7){
            return [
                'name' => 'required',
                'email' => 'required|email|unique:users,email',
                'address' => '',
                'contact_number' => 'numeric',
                'country' => 'required',
                'city' => 'required',
                'pin' => 'required',
                'fax' => 'required',
                'user_type' => 'required',
                'company_id' => 'required',
            ];
        }else if(Request::get('user_type') == 6){
            return [
                'name' => 'required',
                'email' => 'required|email|unique:users,email',
                'address' => '',
                'contact_number' => 'numeric',
                'country' => 'required',
                'city' => 'required',
                'pin' => 'required',
                'fax' => 'required',
                'user_type' => 'required',
                'vendor_id' => 'required'
            ];
        }else {
            return [
                'name' => 'required',
                'email' => 'required|email|unique:users,email',
                'address' => '',
                'contact_number' => 'numeric',
                'country' => 'required',
                'city' => 'required',
                'pin' => 'required',
                'fax' => 'required',
                'user_type' => 'required'
            ];
        }
        
    }
}
