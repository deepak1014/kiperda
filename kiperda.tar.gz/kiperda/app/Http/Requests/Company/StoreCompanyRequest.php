<?php

namespace App\Http\Requests\Company;

use App\Http\Requests\Request;

class StoreCompanyRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return auth()->user()->can('company-create');
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => 'required',
            'email' => 'required|email',
            'website' => 'required',
            'contact_number' => 'required',
            'alternate_contact_number' => 'required',
            'address' => '',
            'pin' => 'max:6',
            'city' => '',
            'currency' => 'required'
        ];
    }
}
