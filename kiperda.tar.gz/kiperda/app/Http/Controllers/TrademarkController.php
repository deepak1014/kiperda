<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Companie;
use App\Models\Trademarksubtype;
use App\Models\SubService;
use App\Repository\Trademark\TrademarkRepositoryContract;
use App\Repository\Trademark\TrademarkRepository;
use DB;


class TrademarkController extends Controller
{

    public function index()
    {
    	return view('trademark.index');

    }
    public function create()
    {
      $companydocuments=DB::table('companydocumemttypes')->select('*')->get();
        $services=DB::table('services')->select('*')->get();
        $user = DB::table('role_user')
        ->join('users','role_user.user_id','=','users.id')
        ->join('roles','role_user.role_id','=','roles.id')
        ->select(['users.name as username', 'users.id'])->whereIn('role_id',[1,4])->get();
        $companies=DB::table('companies')->select('*')->get();
        $country=DB::table('countries')->select('*')->get();
        $company_classification=DB::table('company_classifications')->select('*')->get();
        $trademarktype=DB::table('trademarktype')->select('*')->get();
         return view('trademark.create',compact('country','companies','user','company_classification','trademarktype','services','companydocuments','checklist'));

    }
    
    public function store(StoreTrademarkRequest $trademarkRequest){
        $this->trademark->create($trademarkRequest);

        return redirect()->route('trademark.completerecord');
    }

    public function completeRecord($id){
        $trademark = Trademark::find($id);        
        return view('trademark.completerecord', compact('trademark'));
    }



/*public function store(Request $request)
     {
        echo "hello world";
    
     }      
*/
public function findChecklistoption($id)
{
  echo "hello world";
}






public function findClientid($id)
{
  $companydocuments= DB::table('companydocuments')->select('*')->where('company_id',$id)->get();

 return view('trademark.new_create', array('companydocuments' => $companydocuments)); 
 //return view('trademark.completerecord')->with('name', 'Victoria');
    
}

     public function trademarksubtype($id)
{  

 $trademarksubtype=Trademarksubtype::where('sub_type_id',$id)->get();

?> 
<div class="form-group">
<select class="form-control">
<?php
foreach($trademarksubtype as $value)
        {?>
          <option value="<?php echo $value['sub_type_id'] ?>"><?php echo $value['sub_type_name'] ?></option>

          <?php  } ?>
       </select>   
       </div>
<?php
}
public function subservicetype($id)
{
    $subservice=SubService::where('service_id',$id)->get();
?> 
<div class="form-group">
<select class="form-control">
<?php
foreach($subservice as $value)
        {?>
          <option value="<?php echo $value['service_id'] ?>"><?php echo $value['name'] ?></option>

          <?php  } ?>
       </select> 
</div>
<?php
}


}     


