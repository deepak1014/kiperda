<?php
namespace App\Http\Controllers;
use Gate;
use Carbon;
use DB;
use Datatables;
use App\Models\User;
use App\Models\Tasks;
use App\Http\Requests;
use App\Models\Companie;
use App\Models\Companies_addresses;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use PHPZen\LaravelRbac\Traits\Rbac;
use Illuminate\Support\Facades\Input;
use App\Http\Requests\Company\UpdateCompanyRequest;
use App\Http\Requests\Company\StoreCompanyRequest;
use App\Repositories\User\UserRepositoryContract;
use App\Repositories\Company\CompanyRepositoryContract;
use App\Repositories\Role\RoleRepositoryContract;
use App\Repositories\Department\DepartmentRepositoryContract;
use App\Repositories\Setting\SettingRepositoryContract;
use App\Http\Controllers\Settings;
use View;
error_reporting(0);
class CompaniesController extends Controller
{
    protected $users;
    protected $companies;
    protected $companies_addresses;
    protected $settings;

    public function __construct(
        UserRepositoryContract $users,
        CompanyRepositoryContract $companies,
        SettingRepositoryContract $settings
    ) {
        $this->users = $users;
        $this->companies = $companies;
        $this->settings = $settings;
        $this->middleware('company.create', ['only' => ['create']]);
        $this->middleware('company.update', ['only' => ['edit']]);
    }
	
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('companies.index');
    }
	
    
	/*
	*
	*Get All data of companies
	*/
	
	public function anyData()
    {
        $canUpdateUser = auth()->user()->can('update-company');
        $companies = Companie::select(['id', 'name', 'email', 'contact_number', 'status']);
        
        
        return Datatables::of($companies)
        ->addColumn('namelink', function ($companies) {
                return '<a href="companies/'.$companies->id.'" ">'.$companies->name.'</a>';
        })

        ->add_column('edit', '
                <a href="{{ route(\'companies.edit\', $id) }}" class="btn btn-success" >Edit</a>')
        ->add_column('delete', '
                <form action="{{ route(\'companies.destroy\', $id) }}" method="POST">
            <input type="hidden" name="_method" value="DELETE">
            <input type="submit" name="submit" value="Delete" class="btn btn-danger" onClick="return confirm(\'Are you sure?\')"">

            {{csrf_field()}}
            </form>')
//        ->add_column('status', '
//                <form action="{{ route(\'companies.status\', $id) }}" method="POST">
//            <input type="hidden" name="status" value="false">
//            <input type="checkbox" value="true" name="status" class="btn btn-danger" {{ ($companies->status==1)? \'checked\': \'checked\'}}
//            
// onChange="this.form.submit()" >
//
//            {{csrf_field()}}
//            </form>')
                 ->addColumn('status', function ($companies) {
                 $test= '<form action="' . route('companies.status', $companies->id).'" method="POST">
             <input type="hidden" name="status" value="false">';
      $test.=csrf_field();
           $test.= ' <input type="checkbox" name="status" value="true" class="btn btn-danger"';
                         
                
                 
               if($companies->status==1)
               {
               $test.= 'checked="checked"';
               }
               $test.= ' onChange="this.form.submit()" >
                
        </form>';
           return  $test;    
  })
 
                
        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create() {
        $companyclassification = DB::table('company_classifications')->get();
           // print_r($companyclassification);
           // exit();
//          $itemsisgroup = Companie::orderBy('id', 'asc')
//                ->where('is_group', true)
//                ->get();
        $itemsisgroup = Companie::where('is_group', true)->orderBy('name')->pluck('name', 'id');
         // $itemsisgroup = Companie::pluck('name', 'id');
          return view('companies.create', compact('itemsisgroup','companyclassification'));

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    
     public function store(StoreCompanyRequest $request)
    {
         
        $this->companies->create($request);
        Session()->flash('flash_message', 'Company created');
          return redirect()->route('companies.index');
        //return redirect()->back();
    }
    

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id,Request $request)
    {
       $this->companies->show($request); 
        
        
       //  $settings = Settings::first();
        $companyname = "Media";
        return view('companies.show',compact('companyname'))
          ->withCompany($this->companies->find($id));
    }

    /**
     * Show the form for editing the specified resource.
     *Create and edit by satya 21 Nov 2016
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */ 
    public function edit($id) {
        $companyclassification = DB::table('company_classifications')->get();
          
        $selectedCompaniedata = Companie::orderBy('id', 'asc')
                ->where('id', $id)
                ->get();
      $selectedCompanie = $selectedCompaniedata[0]['group_id'];
       // exit();
        
        $type = $selectedCompaniedata[0]['type'];
        
//        $itemsisgroup = Companie::orderBy('id', 'asc')
//                ->where('is_group', true)
//                ->get();
  $itemsisgroup = Companie::where('is_group', true)->orderBy('name')->pluck('name', 'id');
        $items = Companies_addresses::orderBy('id', 'asc')
                ->where('company_id', $id)
                ->get();


        return view('companies.edit', compact('items', 'itemsisgroup', 'selectedCompanie','type','companyclassification'))
                        ->withCompanies($this->companies->find($id));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return ResponseUpdateClientRequest
     */
    public function update($id, UpdateCompanyRequest $request)
    {
        $this->companies->update($id, $request);
        
        Session()->flash('flash_message', 'Company successfully updated');
          return redirect()->route('companies.index');
        //return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $this->companies->destroy($id);
        
        return redirect()->route('companies.index');
    }
    public function changestatus($id)
    {
        
        
      $this->companies->changestatus($id);
        
        return redirect()->route('companies.index');
    }
    public function status($id)
    {
    
      $this->companies->status($id);
        
        return redirect()->route('companies.index');
    }
    
    
    
    
    
}
