<?php
namespace App\Http\Controllers;

use Config;
use Dinero;
use Datatables;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\Vendor\StoreVendorRequest;
use App\Http\Requests\Vendor\UpdateVendorRequest;
use App\Models\Vendor;
use App\Models\Vendors_Address;
use App\Models\Country;
use App\Repositories\Vendor\VendorRepositoryContract;
use App\Repositories\Setting\SettingRepositoryContract;
use View;
error_reporting(0);
class VendorsController extends Controller
{
    protected $vendors;
    protected $settings;

    public function __construct(
        VendorRepositoryContract $vendors,
        /*ClientRepositoryContract $clients,*/
        SettingRepositoryContract $settings
        
    ) {
        $this->vendors = $vendors;
        $this->settings = $settings;
        //$this->middleware('client.create', ['only' => ['create']]);
        //$this->middleware('client.update', ['only' => ['edit']]);
    }
    public function index()
    {
      return view('vendors.index');
    }
    public function anyData()
    {
        $vendors = Vendor::select(['id','name','email','status','contact_number'])->get();
        return Datatables::of($vendors)
        ->addColumn('namelink', function ($vendors) {
                return '<a href="vendors/'.$vendors->id.'" ">'.$vendors->name.'</a>';
        })
       ->add_column('edit', '
                <a href="{{ route(\'vendors.edit\', $id) }}" class="btn btn-success" >Edit</a>')
      ->addColumn('status', function ($vendors) {
         $test= '<form action="' . route('vendors.status', $vendors->id).'" method="POST">
             <input type="hidden" name="status" value="false">';
             $test.=csrf_field();
             $test.= ' <input type="checkbox" name="status" value="true" class="btn btn-danger"';
                if($vendors->status==1)
               {
               $test.= 'checked="checked"';
               }
               $test.= ' onChange="this.form.submit()">
               
        </form>';
           return  $test;   
  })
            ->make(true);

    }

    

    public function create()
    {
         
        $country=DB::table('countries')->select('*')->get();
        return view('vendors.create',compact('country'));
        
    }
    public function show($id)
    {
        return view('vendors.show')
          ->withVendor(Vendor::find($id));
    }
   public function store(StoreVendorRequest $request)
    {
        $this->vendors->create($request);
        Session()->flash('flash_message', 'Vendor successfully added');
        return redirect()->route('vendors.index');
    }
     public function edit($id)
    {
       $countryid=Vendor::orderBy('id','asc')->where('id',$id)->get();



       $countryvalue=$countryid[0]['country'];
       
         $country=DB::table('countries')->select('*')->get();
        //return view('vendors.create',compact('country'));
        $items=Vendors_Address::orderBy('id','asc')->where('vendor_id',$id)->get();

 //return view('vendors.edit',compact($items));

 return view('vendors.edit',compact('items','country','countryvalue'))
        ->withVendor(Vendor::find($id));
     
        /*->withAddress(Address::find($address_id));
        */
    
    }
    public function update($id, UpdateVendorRequest $request)
    {
        $this->vendors->update($id, $request);
        Session()->flash('flash_message', 'Vendor successfully updated');
        return redirect()->back();
    }
     /*  $addarray=$request->address;
print_r($addarray);

foreach($addarray as $value)
{

$update=Address::where('vendor_id','=',$id)
->update('address'->$value);
}
*/
        /*$input = $request->all();
        $Vendor = Vendor::findorfail($id);

        $updateNow = $Vendor->update($input);
        Session()->flash('flash_message', 'Vendor successfully updated');
        return redirect()->route('vendors.index');
    */
    public function destroy($id)
    {
        Vendor::destroy($id);
        return redirect()->route('vendors.index');
    }
    public function status($id)
    {
       $count=$this->vendors->status($id);


       return redirect()->route('vendors.index'); 
    }
    
    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
}


