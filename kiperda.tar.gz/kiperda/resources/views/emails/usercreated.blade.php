Your account has been created. Please click on the below link to activate
the user account.

{{ url('/password/create/'.$token) }}