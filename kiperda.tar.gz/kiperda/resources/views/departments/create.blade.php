@extends('layouts.master')

@section('content')
{!! Form::open([
        'route' => 'departments.store',
        ]) !!}
<input type="hidden" name="_token" value="{{ csrf_token() }}">
<div class="form-group">
    {!! Form::label(Lang::get('department.titles.name'), 'Department name:', ['class' => 'control-label']) !!}
    {!! Form::text('name', null,['class' => 'form-control']) !!}
</div>

<div class="form-group">
    {!! Form::label(Lang::get('department.titles.description'), 'Department description:', ['class' => 'control-label']) !!}
    {!! Form::textarea('description', null, ['class' => 'form-control']) !!}
</div>
{!! Form::submit(Lang::get('department.titles.create'), ['class' => 'btn btn-primary']) !!}

{!! Form::close() !!}

@endsection