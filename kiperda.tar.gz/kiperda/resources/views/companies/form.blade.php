<div class="form-group">
    {!! Form::label('name', Lang::get('company.headers.name'), ['class' => 'control-label']) !!}
    {!! Form::text('name', null,['class' => 'form-control']) !!}
</div>
<div class="form-group">
    {!! Form::label('active', Lang::get('company.headers.active'), ['class' => 'control-label']) !!}
<!--    {!! Form::checkbox('is_group', 1,['class' => 'form-control'],['autocomplete' => 'off']) !!}-->
{{ Form::checkbox('is_group', '1') }}
</div>
<div class="input_fields_wrap">
    <button class="add_field_button">Add More Fields</button>
    @if (count($items)>0)  
    @foreach($items as $item)
    <div class="form-group">
    {!! Form::label('address', Lang::get('company.headers.address'), ['class' => 'control-label']) !!}
    {!! Form::text('address[]', $item->address_line_1,['class' => 'form-control'],['id' => 'txtPlaces']) !!}
    </div>
    @endforeach
@else
    <div class="form-group">
    {!! Form::label('address', Lang::get('company.headers.address'), ['class' => 'control-label']) !!}
    {!! Form::text('address[]', null,['class' => 'form-control']) !!}
    </div>
@endif

</div>

<div class="form-group">
    {!! Form::label('mail', Lang::get('company.headers.mail'), ['class' => 'control-label']) !!}
   &nbsp; &nbsp; {!! Form::text('email', null,['class' => 'form-control']) !!}
</div>
<div class="form-group">
    {!! Form::label('contact_number', Lang::get('company.headers.contact_number'), ['class' => 'control-label']) !!}
    {!! Form::text('contact_number', null,['class' => 'form-control']) !!}
</div>
<div class="form-group">
    {!! Form::label('alternate_contact_number', Lang::get('company.headers.alternate_contact_number'), ['class' => 'control-label']) !!}
    {!! Form::text('alternate_contact_number', null,['class' => 'form-control']) !!}
</div>
<div class="form-group">
    {!! Form::label('website', Lang::get('company.headers.website'), ['class' => 'control-label']) !!}
    {!! Form::text('website', null,['class' => 'form-control']) !!}
</div>

<div class="form-group">
    {!! Form::label('logo_path', Lang::get('company.headers.logo_path'), ['class' => 'control-label']) !!}
    {!! Form::file('logo_path', null,['class' => 'form-control']) !!}

</div>



<div class="form-group">
{{ Form::select('is_group', $itemsisgroup, $selectedCompanie,['class' => 'form-control']) }}
    
<!--    <select name="group_id" class = "form-control">
       @foreach($itemsisgroup as $itemsvalue) 
       <option value="{{ $itemsvalue->id}}" {{ $selectedCompanie == $itemsvalue->id ? 'selected=selected' : '' }}>{{ $itemsvalue->name}}</option>
        @endforeach
       
    </select>-->
</div>

<div class="form-group">
    {!! Form::label('type', Lang::get('company.headers.type'), ['class' => 'control-label']) !!}<br>
    <select name="type" class = "form-control">
       @foreach($companyclassification as $itemsvalue) 
       <option value="{{ $itemsvalue->classification_name}}" {{ $type == $itemsvalue->classification_name ? 'selected=selected' : '' }}>{{ $itemsvalue->classification_name}}</option>
        @endforeach
     </select>
</div>
<!--
Company, LLP, LLC, Corporation, Partnership, Sole
Proprietorship, Public Limited Company and Individual-->


<div class="form-group">
    {!! Form::label('currency', Lang::get('company.headers.currencyname'), ['class' => 'control-label']) !!}
</div>
<div class="form-group">
    {!! Form::label('currency', Lang::get('company.headers.currency'), ['class' => 'control-label']) !!}
    {!! Form::radio('currency', 'USD',['class' => 'form-control']) !!}
    
    {!! Form::label('currency', Lang::get('company.headers.currency1'), ['class' => 'control-label']) !!}
    {!! Form::radio('currency', 'EURO',['class' => 'form-control']) !!}
</div>


<!--{{ Form::radio('sex', 'male') }}<br>
{{ Form::radio('sex', 'female') }}-->


{!! Form::submit(Lang::get('company.headers.add_new'), ['class' => 'btn btn-primary']) !!}



		



