@extends('layouts.master')
@section('heading')
<h1>@lang('company.titles.all')</h1>
@stop

@section('content')

   <table  width="100%" >
         <tr>
                <th align="right"> <a href="{{ route('companies.create')}}"><button class="btn btn-primary pull-right">@lang('Add New')</button></a></th>
               
            </tr>
         <tr>
                <th align="right" height="10">&nbsp; </th>
               
            </tr>
       </table>
   <table class="table table-hover " id="company-table">
     
        <thead>
            <tr>
                <th>@lang('company.headers.name')</th>
                <th>@lang('company.headers.mail')</th>
                <th>@lang('company.headers.contact_number')</th>
                <th>@lang('company.headers.edit')</th>                
                <th>@lang('company.headers.delete')</th>                
                <th>@lang('company.headers.status')</th>
            </tr>
        </thead>
    </table>
  
@stop

@push('scripts')
<script>
$(function() {
    $('#company-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: '{!! route('companies.data') !!}',
        columns: [
            
            { data: 'namelink', name: 'name' },
            { data: 'email', name: 'email' },
            { data: 'contact_number', name: 'contact_number' },
            @if(Entrust::can('company-update'))  
            {data: 'edit', name: 'edit', orderable: false, searchable: false  },
            { data: 'delete', name: 'delete', orderable: false, searchable: false},
            { data: 'status', name: 'status' },
            @endif      
        ]
    });
});
</script>
@endpush
