

@extends('layouts.master')

@section('heading')

<h1>@lang('company.titles.edit')</h1>
@stop

@section('content')
<script>
$(document).ready(function() {
    var max_fields      = 10; //maximum input boxes allowed
    var wrapper         = $(".input_fields_wrap"); //Fields wrapper
    var add_button      = $(".add_field_button"); //Add button ID
   
    var x = 1; //initlal text box count
    $(add_button).click(function(e){ //on add input button click
        e.preventDefault();
        if(x < max_fields){ //max input box allowed
            x++; //text box increment
            $(wrapper).append('<div><input type="text" name="mytext[]" class="form-control"/><a href="#" class="remove_field">Remove</a></div>'); //add input box
        }
    });
   
    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
        e.preventDefault(); $(this).parent('div').remove(); x--;
    })
});
            
</script> 

{!! Form::model($companies, [
        'method' => 'PATCH',
        'route' => ['companies.update', $companies->id],
        'files'=>true,
        'enctype' => 'multipart/form-data'
        ]) !!}
        
@include('companies.form', ['submitButtonText' => Lang::get('companies.headers.update_submit')])

{!! Form::close() !!}

@stop