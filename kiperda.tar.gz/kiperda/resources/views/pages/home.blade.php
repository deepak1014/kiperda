@extends('layouts.master')

@section('heading')
<h1>Hello world</h1>
@stop


@section('content')
    
    <p>Dashboard Comeing in later Version???</p>

@stop