@extends('layouts.master')
@section('heading')
<h1>@lang('trademark.titles.create')</h1>
 
@stop

@section('content')
{!! Form::open([
        'route' => 'trademark.store',
        'files'=>true,
        'enctype' => 'multipart/form-data'

        ]) !!}
@include('trademark.form_2', ['submitButtonText' => Lang::get('trademark.headers.create_submit')])


{!! Form::close() !!}
@stop