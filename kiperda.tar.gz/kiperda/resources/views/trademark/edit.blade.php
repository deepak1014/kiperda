@extends('layouts.master')
@section('heading')
Edit Vendor ({{$vendor->name}})
@stop

@section('content')
{!! Form::model($vendor, [
        'method' => 'PATCH',
        'route' => ['vendors.update', $vendor->id],
        'files'=>true,
        'enctype' => 'multipart/form-data'

        ]) !!}
@include('vendors.form', ['submitButtonText' => Lang::get('client.titles.update')])

{!! Form::close() !!}
	
@stop