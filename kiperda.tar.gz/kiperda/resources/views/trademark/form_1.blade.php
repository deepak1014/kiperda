<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <title>Flarepoint CRM</title>
   <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script type="text/javascript" src="{{ URL::asset('js/trademark.js') }}"></script>
  <link href="{{ URL::asset('css/trademark.css') }}" rel="stylesheet" type="text/css" >
<script type="text/javascript">
function findClientid(id)
{
     $.ajax({
        url:'/trademark/getid/'+id,
        data:{'id':id},
       success: function(response)
    {
      console.log(response);
        /* $("#sub").show();
       $("#sub").html(response);*/
    }


    });


}
</script>
</head>
  
 
  


 <div style="height:40px;"></div>
    <div class="assessment-container container">
        <div class="row">
            <div class="col-md-6 form-box">
                


                <form action="{{url('trademarksubtype')}}" id="trademark_sub_type" role="form" class="registration-form" action="javascript:void(0);">
                <input type="hidden" name="_token" value="{{csrf_token()}}">
                <!--..first fieldset start..--> 
                    <fieldset id="box-1">
                    @foreach($companydocuments as $value)
                    {{$value->documenttypename}}
                    @endforeach 
                        <div class="form-top">
                            <div class="form-top-left">
                                <h3><span><i class="fa fa-trademark" aria-hidden="true"></i>
</span> &nbsp Create Record</h3>
<p>all(<span class="required"></span>) fields are mandatory</p>  

                                                            </div>
                        </div>
                        <div class="form-bottom">
                            <div class="row">
                                <div class="form-group">
                               {{Form::label('email', 'Trademark Name')}}
                                   {{Form::text('trademark_name','',['class'=>'form-control'])}}
                                </div>
                                

                               
                                    


                                <div class="form-group">
                                    <select name="trademarktype" class="form-control" id="trademark_type" onChange="findTrademarkType(this.value)">
                                    <option>Trademark Type</option>
                                    @foreach($trademarktype as $value)
                                    <option value="{{$value->id}}">{{$value->type_name}}</option>
                                    @endforeach
                                    </select>
                    
                                </div>
                                 <!--  <span id="sub" style="display:none;">
                               
                                    </span> -->
                                
                                 <div class="form-group">
                                    <select name="services" class="form-control" id="services" onChange="findSubServiceType(this.value)">
                                    <option>Select A Service</option>
                                    @foreach($services as $value)
                                    <option value="{{$value->id}}">{{$value->service_name}}</option>
                                    @endforeach
                                    </select>
                    
                                </div>

                                 <span id="subservicetype" style="display:none;">
                               
                                    </span>

                               
                               <div class="form-group">
                                    <select name="company" class="form-control" onChange="findClientid(this.value)">
                                    @foreach($companies as $value)
                                    <option>Select Client</option>
                                    <option value="{{$value->id}}">{{$value->name}}</option>
                                    @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                   
                                </div>
                                <div class="form-group">                          
                                      <select name="country" class="form-control">
                                        <option>Select Country</option>
                                        @foreach($country as $value)
                                    <option value="{{$value->country_name}}" >{{$value->country_name}}</option>
                                        @endforeach
                                     </select> 
                                </div>
                                <div class="form-group">     
                                      <select name="trademarkstatus" class="form-control">
                                      <option>Select Trademark Status</option>
                                      <option value="abandoned">Anandoned</option>
                                      <option value="casetransferred">Case Transferred</option>
                                      <option value="cautionarynotice">Cautionary Notice</option>
                                      <option value="commonlawmark">Common Low Mark</option>               
                                      <option value="lapsed">Lapsed</option>               
                                      <option value="notyetfiled">Not Yet Filed</option>               
                                      <option value="pending">Pending</option>               
                                      <option value="refused">Refused</option>               
                                      <option value="registered">Registered</option>               
                                      <option value="test">Test</option>               
                                      <option value="withdrawn">Withdrawn</option>               
                                     </select>
                                 </div>       
                            <div class="form-group">
                           <select name="user" class="form-control">
                           <option>Select Supervisor/Action Attorney</option>
                           
                           @foreach($user as $value)
                           <option value="{{$value->username}}">{{$value->username}}</option>
                           @endforeach
                           </select>
                            </div>
                             <div class="form-group">
                                    <input type="text" id="datepicker_1" class="form-control" placeholder="Instruction Date" required>
                                </div>
                            <input type="submit" name="submit" value="insert">
                            <button type="button" class="btn btn-next" id="next_1">Next</button>
                        </div>
                    </fieldset>
                    </form>


                    
</div>

                                   
            </div>
        </div>
    </div>