@foreach($companydocuments as $value)
{{$value->company_id}}
@endforeach