<div id="task" class="tab-pane fade in active">
  <div class="boxspace">
    <table class="table table-hover">
      <h4>@lang('vendor.tabs.all_tasks')</h4>
      <thead>
        <thead>
          <tr>
            <th>@lang('vendor.tabs.headers.title')</th>
            <th>@lang('vendor.tabs.headers.assigned')</th>
            <th>@lang('vendor.tabs.headers.created_at')</th>
            <th>@lang('vendor.tabs.headers.deadline')</th>
            <th><a href="{{ route('tasks.create', ['vendor' => $vendor->id])}}"><button class="btn btn-success">@lang('vendor.tabs.headers.new_task')</button> </a></th>
            </tr>
        </thead>
        <tbody>
          <?php  $tr =""; ?>
          var_dump($vendor);die();

         
          <tr style="background-color:<?php echo $tr ;?>">
            
            <td ></td>
            <td > <div class="popoverOption"
              rel="popover"
              data-placement="left"
              data-html="true"
              data-original-title="<span class='glyphicon glyphicon-user' aria-hidden='true'> </span> ">
              <div id="popover_content_wrapper" style="display:none; width:250px;">
                <img src='http://placehold.it/350x150' height='80px' width='80px' style="float:left; margin-bottom:5px;"/>
                <p class="popovertext">
                  <span class="glyphicon glyphicon-envelope" aria-hidden="true"> </span>
                  <a href="mailto:">
                    <br />
                  </a>
                  <span class="glyphicon glyphicon-headphones" aria-hidden="true"> </span>
                  <a href="mailto:">
                  </p>
                </a>
                
              </div>
              
              </div> <!--Shows users assigned to task -->
            </td>
            <td></td>
          </tr>
          
         
          
        </tbody>
      </table>
    </div>