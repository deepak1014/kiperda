@extends('layouts.master')
@section('heading')
@stop
@section('content')
   <table class="table table-hover " id="vendors-table">
   <a href="{!!route('trademark.create')!!}" class="btn btn-primary pull-right" role="button">Create New Trademark</a>
        <thead>
            <tr>
                <th>@lang('user.headers.name')</th>
                <th>@lang('user.headers.mail')</th>
                <th>@lang('user.headers.contact_number')</th>
                <th>@lang('user.headers.type')</th>
                <th></th>
                <th></th>
            </tr>
        </thead>
    </table>
  

@stop

