<?php

return [

    'titles' => [
        'all' => 'All companies',
        'create' => 'Create company',
        'edit' => 'Editing company',
    ],

    'headers' => [
    	'name' => 'Name',
    	'mail' => 'Email',
    	'address' => 'Address',
    	'contact_number' => 'Contact number',
    	'status' => 'Status',
    	'edit' => 'Edit',
    	'personal_number' => 'Personal number',
    	'password' => 'Password',
    	'password_confirm' => 'Password Confirmation',
    	'assign_role' => 'Assign Role',
    	'assign_department' => 'Assign Department',
    	'image' => 'Choose an image',
    	'create_submit' => 'Create new user',
        'update_submit' => 'Update user'
    ],
    
    'tabs' => [
    	'tasks' => 'Tasks',
    	'leads' => 'Leads',
    	'documents' => 'Documents',
    	'invoices' => 'Invoices',
    	'all_tasks' => 'All tasks',
    	'all_leads' => 'All leads',
    	'all_documents' => 'All documents',
    	'max_size' => 'Max 5MB pr. file',
    	//Headers on tables in tables
    		'headers' => [
    		//Title && Leads
    			'title' => 'Title',
    			'assigned' => 'Assigned user',
    			'created_at' => 'Created at',
    			'deadline' => 'Deadline',
    			'new_task' => 'Add new task',
    			'new_lead' => 'Add new lead',
    			//Documments
		    	'file' => 'File',
    			'size' => 'Size',
    			//Invoices
    			'id' => 'ID',
    			'hours' => 'Hours',
    			'total_amount' => 'Total amount',
    			'invoice_sent' => 'Invoice sent',
    			'payment_received' => 'Payment received',
    		],
    ],
];
