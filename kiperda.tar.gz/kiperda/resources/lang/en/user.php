<?php

return [

    'titles' => [
        'all' => 'All users',
        'create' => 'Create user',
        'edit' => 'Editing user',
    ],

    'headers' => [
    	'name' => 'Name',
    	'mail' => 'Email',
    	'address' => 'Address',
    	'contact_number' => 'Contact number',
        'alternate_contact_number' => 'Alternate contact number',
        'dob' => 'Date of birth',
        'image_path' => 'Profile picture',
    	'country' => 'Country',
    	'city' => 'City',
    	'pin' => 'Pin',
        'fax' => 'Fax or Telephone',
    	'user_type' => 'User type',
    	'assign_department' => 'Assign Department',
    	'image' => 'Choose an image',
    	'create_submit' => 'Create new user',
        'update_submit' => 'Update user',
        'business_card' => 'Upload business card',
        'national_id' => 'National ID Details',
        'type' => 'Type',
        'company' => 'Choose Company',
        'vendor' => 'Choose Vendor'
    ],

    'travel' => [
        'country' => 'Country travelled ',
        'visa_details' => 'Passport Details with Expiry Date',
        'travelling_summary' => 'Travelling Summary',
        'booking_details' => 'Booking details',
        'boarding_pass' => 'Boarding Pass',
    ],

    'bank' => [
        'bank_name' => 'Bank name',
        'branch_name' => 'Bank branch name',
        'branch_address' => 'Bank address',
        'account_type' => 'Account type',
        'account_number' => 'Account number',
        'swift_code' => 'SWIFT code',
        'ifsc_code' => 'IFSC code'
    ],
];
