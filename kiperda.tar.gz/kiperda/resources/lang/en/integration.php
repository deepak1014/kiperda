<?php

return [
    'headers' =>  [
        'integrations' => 'All Integrations',
        'api_key' => 'Api Key',
        'orginatzion_id' => 'Organization Id',
        'update' => 'Update',
    ],
];