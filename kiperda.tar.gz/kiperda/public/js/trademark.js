/*function findClientid(id)
{
        

    $.ajax({
        url:'/trademark/getid/'+id,
        data:{'id':id},
       success: function(response)
    {
       console.log(response);
    }


    });


}

*/

function findTrademarkType(id)
{
        

    $.ajax({
        url:'/trademark/trademarksubtype/'+id,
        data:{'id':id},
       success: function(response)
    {
         $("#sub").show();
       $("#sub").html(response);
    }


    });


}
function findSubServiceType(id)
{
    $.ajax({
        url:'/trademark/subservicetype/'+id,
        data:{'id':id},
       success: function(response)
    {
        console.log(response);
         $("#subservicetype").show();
       $("#subservicetype").html(response);
    }


    });


}






    $( function() {
    $( "#datepicker_1" ).datepicker();
    $( "#datepicker_2" ).datepicker();
    $( "#datepicker_3" ).datepicker();
    $( "#datepicker_4" ).datepicker();
    $( "#datepicker_5" ).datepicker();
    $( "#datepicker_6" ).datepicker();
    $( "#datepicker_7" ).datepicker();
    $( "#datepicker_8" ).datepicker();
    $( "#datepicker_9" ).datepicker();
    
    
    
    
 $(document).ready(function () {


    
    $("#next_1").click(function()
    {
       
        $("#box-1").hide();
        $("#box-2").fadeIn('slow');
    });
    $("#next_2").click(function()
    {
       
        $("#box-2").hide();
        $("#box-3").fadeIn('slow');
         
    });
    $("#next_3").click(function()
    {
       
        $("#box-3").hide();
        $("#box-4").fadeIn('slow');
    });
   $("#next_4").click(function()
    {
       
        $("#box-4").hide();
        $("#box-5").fadeIn('slow');
    });

 $("#next_5").click(function()
    {
       
        $("#box-5").hide();
        $("#box-6").fadeIn('slow');
    });
 $("#next_6").click(function()
    {
       
        $("#box-6").hide();
        $("#box-7").fadeIn('slow');
    });

     $("#previous_1").click(function()
    {
       
        $("#box-1").fadeIn('slow');
        $("#box-2").hide();
    });
    $("#previous_2").click(function()
    {
       
        $("#box-2").fadeIn('slow');
        $("#box-3").hide();
         
    });
    $("#previous_3").click(function()
    {
       
        $("#box-3").fadeIn('slow');
        $("#box-4").hide();
         
    });
    
     $("#previous_4").click(function()
    {
       
        $("#box-4").fadeIn('slow');
        $("#box-5").hide();
    });
       $("#previous_5").click(function()
    {
       
        $("#box-5").fadeIn('slow');
        $("#box-6").hide();
    });
       $("#previous_5").click(function()
    {
       
        $("#box-5").fadeIn('slow');
        $("#box-6").hide();
    });
    $("#previous_6").click(function()
    {
       
        $("#box-6").fadeIn('slow');
        $("#box-7").hide(); 
        
    });
   
 } );
 
   
});
