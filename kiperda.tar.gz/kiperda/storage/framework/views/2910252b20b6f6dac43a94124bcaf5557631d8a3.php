<?php $__env->startSection('heading'); ?>
<h1><?php echo app('translator')->get('user.titles.all'); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

   <table class="table table-hover " id="users-table">
        <thead>
            <tr>
                <th><?php echo app('translator')->get('user.headers.name'); ?></th>
                <th><?php echo app('translator')->get('user.headers.mail'); ?></th>
                <th><?php echo app('translator')->get('user.headers.contact_number'); ?></th>
                <th><?php echo app('translator')->get('user.headers.type'); ?></th>
                <th></th>
                <th></th>
            </tr>
        </thead>
    </table>
  
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(function() {
    $('#users-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: '<?php echo route('users.data'); ?>',
        columns: [
            
            { data: 'namelink', name: 'name' },
            { data: 'email', name: 'email' },
            { data: 'contact_number', name: 'contact_number' },
            { data: 'display_name', name: 'display_name' },
            <?php if(Entrust::can('user-update')): ?>  
            {data: 'edit', name: 'edit', orderable: false, searchable: false  },
            <?php endif; ?>
            <?php if(Entrust::can('user-delete')): ?> 
            {data: 'delete', name: 'delete', orderable: false, searchable: false  },
            <?php endif; ?>
        ]
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>