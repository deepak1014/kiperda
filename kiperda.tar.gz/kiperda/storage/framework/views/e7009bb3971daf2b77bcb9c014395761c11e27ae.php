<?php $__env->startSection('heading'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <table class="table table-hover " id="vendors-table">
   <a href="<?php echo route('trademark.create'); ?>" class="btn btn-primary pull-right" role="button">Create New Trademark</a>
        <thead>
            <tr>
                <th><?php echo app('translator')->get('user.headers.name'); ?></th>
                <th><?php echo app('translator')->get('user.headers.mail'); ?></th>
                <th><?php echo app('translator')->get('user.headers.contact_number'); ?></th>
                <th><?php echo app('translator')->get('user.headers.type'); ?></th>
                <th></th>
                <th></th>
            </tr>
        </thead>
    </table>
  

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>