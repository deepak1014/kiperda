<div class="row">
<div class="col col-lg-6">
<!-- <div class="form-group form-inline">
<?php echo Form::label('roles', Lang::get('user.headers.user_type'), ['class' => 'control-label required']); ?>

<?php echo Form::select('roles',
    $roles, isset($user->userRole->role_id) ? $user->userRole->role_id : null,
    ['placeholder' => 'Choose user type', 'class' => 'form-control']); ?>


</div> -->
<div class="form-group">
    <?php echo Form::label('name', Lang::get('user.headers.name'), ['class' => 'control-label required']); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('email', Lang::get('user.headers.mail'), ['class' => 'control-label required']); ?>

    <?php echo Form::email('email', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('address', Lang::get('user.headers.address'), ['class' => 'control-label required']); ?>

    <?php echo Form::text('address', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('contact_number', Lang::get('user.headers.contact_number'), ['class' => 'control-label required']); ?>

    <?php echo Form::text('contact_number',  null, ['class' => 'form-control']); ?>

</div> 


<div class="form-group form-inline">
<?php echo Form::label('country', Lang::get('user.headers.country'), ['class' => 'control-label required']); ?>

<?php echo Form::select('country',
    $countries, isset($user->country) ? $user->country : null,
    ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('city', Lang::get('user.headers.city'), ['class' => 'control-label required']); ?>

    <?php echo Form::text('city',  null, ['class' => 'form-control']); ?>

</div> 

<div class="form-group">
    <?php echo Form::label('pin', Lang::get('user.headers.pin'), ['class' => 'control-label required']); ?>

    <?php echo Form::text('pin',  null, ['class' => 'form-control']); ?>

</div>  


<div class="form-group">
    <?php echo Form::label('fax', Lang::get('user.headers.fax'), ['class' => 'control-label required']); ?>

    <?php echo Form::text('fax',  null, ['class' => 'form-control']); ?>

</div>

<div class="form-group" style="display: -webkit-box;">
    <div class="col col-lg-6">
        <?php echo Form::label('image_path', Lang::get('user.headers.image_path'), ['class' => 'control-label']); ?>

        <?php echo Form::file('image_path', null, ['class' => 'form-control']); ?>

    </div>
    <div class="col col-lg-6">
        <div id="image_previewUser"><img id="previewingUser" <?php if(isset($user->image_path)): ?> src="../../images/Media/<?php echo e($user->image_path); ?>" <?php else: ?> src="../../images/no-image-box.png"<?php endif; ?> width="50" height="50"/></div>
        <p class="help-block" id="messageUser" style="display:none;"></p>
    </div>
</div>

<div class="form-group" style="display: -webkit-box;">
    <div class="col col-lg-6">
        <?php echo Form::label('business_card', Lang::get('user.headers.business_card'), ['class' => 'control-label']); ?>

        <?php echo Form::file('business_card', null, ['class' => 'form-control']); ?>

    </div>
    <div class="col col-lg-6">
        <div id="image_previewBusinessCard"><img id="previewingBusinessCard" <?php if(isset($user->business_card)): ?> src="../../images/Media/<?php echo e($user->business_card); ?>" <?php else: ?> src="../../images/no-image-box.png"<?php endif; ?> width="50" height="50"/></div>
        <p class="help-block" id="messageBusinessCard" style="display:none;"></p>
    </div>
</div>
<div class="form-group">
    <?php echo e(Form::label('date_of_birth', Lang::get('user.headers.dob'), ['class' => 'control-label'])); ?>

    <?php echo Form::date('date_of_birth',  null, ['class' => 'form-control']); ?>

</div>  

<div class="form-group">
    <?php echo Form::label('alternate_contact_number', Lang::get('user.headers.alternate_contact_number'), ['class' => 'control-label']); ?>

    <?php echo Form::text('alternate_contact_number',  null, ['class' => 'form-control']); ?>

</div> 

<div class="form-group">
    <?php echo Form::label('national_id', Lang::get('user.headers.national_id'), ['class' => 'control-label']); ?>

    <?php echo Form::text('national_id',  null, ['class' => 'form-control']); ?>

</div> 
<?php echo Form::submit($submitButtonText, ['class' => 'btn btn-primary']); ?>

</div>
<div class="col col-lg-6">
<div class="form-group">
    <h4>Bank details</h4>
</div>

<div class="form-group">
    <?php echo Form::label('bank_name', Lang::get('user.bank.bank_name'), ['class' => 'control-label']); ?>

    <?php echo Form::text('bank_name',  null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('branch_name', Lang::get('user.bank.branch_name'), ['class' => 'control-label']); ?>

    <?php echo Form::text('branch_name',  null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('branch_address', Lang::get('user.bank.branch_address'), ['class' => 'control-label']); ?>

    <?php echo Form::text('branch_address',  null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('account_type', Lang::get('user.bank.account_type'), ['class' => 'control-label']); ?>

    <?php echo Form::text('account_type',  null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('account_number', Lang::get('user.bank.account_number'), ['class' => 'control-label']); ?>

    <?php echo Form::text('account_number',  null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('swift_code', Lang::get('user.bank.swift_code'), ['class' => 'control-label']); ?>

    <?php echo Form::text('swift_code',  null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('ifsc_code', Lang::get('user.bank.ifsc_code'), ['class' => 'control-label']); ?>

    <?php echo Form::text('ifsc_code',  null, ['class' => 'form-control']); ?>

</div>

<div class="form-group form-inline">
<?php echo Form::label('user_type', Lang::get('user.headers.user_type'), ['class' => 'control-label required']); ?>

<?php echo Form::select('user_type',
    $roles, isset($user->userRole->role_id) ? $user->userRole->role_id : null,
    ['placeholder' => 'Choose user type', 'class' => 'form-control']); ?>


</div>

<div id="kipgUserProfile" style="display: none;">
    <div class="form-group">
        <h4>Travel Profile</h4>
    </div>

    <div class="form-group">
        <?php echo Form::label('country_travelled', Lang::get('user.travel.country'), ['class' => 'control-label']); ?>

        <?php echo Form::select('country_travelled',
        $countries, '99',
        ['class' => 'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('visa_details', Lang::get('user.travel.visa_details'), ['class' => 'control-label']); ?>

        <?php echo Form::text('visa_details',  null, ['class' => 'form-control']); ?>

    </div>  

    <div class="form-group">
        <?php echo Form::label('travelling_summary', Lang::get('user.travel.travelling_summary'), ['class' => 'control-label']); ?>

        <?php echo Form::text('travelling_summary',  null, ['class' => 'form-control']); ?>    
    </div>
    <div class="form-group">
        <?php echo Form::label('booking_details', Lang::get('user.travel.booking_details'), ['class' => 'control-label']); ?>

        <?php echo Form::text('booking_details', null, ['class' => 'form-control']); ?>    
    </div>
    <div class="form-group">
        <?php echo Form::label('boarding_pass', Lang::get('user.travel.boarding_pass'), ['class' => 'control-label']); ?>

        <?php echo Form::text('boarding_pass', null, ['class' => 'form-control']); ?>    
    </div>
</div>

<div class="form-group form-inline" id="companyDropdown" style="display:none;">
<?php echo Form::label('company_id', Lang::get('user.headers.company'), ['class' => 'control-label required']); ?>

<?php echo Form::select('company_id',
    $companies, isset($user->company_id) ? $user->company_id : null,
    ['placeholder' => 'Choose company', 'class' => 'form-control']); ?>


</div>

<div class="form-group form-inline" id="vendorsDropdown" style="display:none;">
<?php echo Form::label('vendor_id', Lang::get('user.headers.vendor'), ['class' => 'control-label required']); ?>

<?php echo Form::select('vendor_id',
    $vendors, isset($user->vendor_id) ? $user->vendor_id : null,
    ['placeholder' => 'Choose vendor', 'class' => 'form-control']); ?>


</div>

</div>
</div>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    $(document).on('change', '#user_type', function(){
        /*travel profile is required only for KIPG users*/
        var roleId = $(this).val();
        if(roleId == 1 || roleId == 4){
            $('#kipgUserProfile').show();
            $('#vendorsDropdown').hide();
            $('#companyDropdown').hide();
        }else if(roleId == 6){
            $('#vendorsDropdown').show();
            $('#kipgUserProfile').hide();
            $('#companyDropdown').hide();
        }else if(roleId == 7){
            $('#companyDropdown').show();
            $('#vendorsDropdown').hide();
            $('#kipgUserProfile').hide();
        }else if(roleId == 5){
            $('#vendorsDropdown').show();
            $('#companyDropdown').show();
            $('#kipgUserProfile').hide();
        }else{
            $('#kipgUserProfile').hide();
        }
        
    });

    $(document).on('change', '#image_path', function(){
        var file = this.files[0];
        var imagefile = file.type;
        var match= ["image/jpeg","image/png","image/jpg"];
        if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2])))
        {
            $('#previewingUser').attr('src','../../images/no-image-box.png');
            $("#messageUser").html("<p class='error'>Please Select A valid Image File</p>"+"<h4>Note</h4>"+"<span class='error_message'>Only jpeg, jpg and png Images type allowed</span>");
            $("#messageUser").show();
            return false;
        }
        else
        {
            var reader = new FileReader();
            reader.onload = imageIsLoadedUser;
            reader.readAsDataURL(this.files[0]);
        }
    });

    function imageIsLoadedUser(e) {
        $("#messageUser").hide();
        $("#file").css("color","green");
        $('#image_previewUser').css("display", "block");
        $('#previewingUser').attr('src', e.target.result);
        $('#previewingUser').attr('width', '50px');
        $('#previewingUser').attr('height', '50px');
    };

    $(document).on('change', '#business_card', function(){
        var file = this.files[0];
        var imagefile = file.type;
        var match= ["image/jpeg","image/png","image/jpg"];
        if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2])))
        {
            $('#previewingBusinessCard').attr('src','../../images/no-image-box.png');
            $("#messageBusinessCard").html("<p class='error'>Please Select A valid Image File</p>"+"<h4>Note</h4>"+"<span class='error_message'>Only jpeg, jpg and png Images type allowed</span>");
            $("#messageBusinessCard").show();
            return false;
        }
        else
        {
            var reader = new FileReader();
            reader.onload = imageIsLoadedBusinessCard;
            reader.readAsDataURL(this.files[0]);
        }
    });

    function imageIsLoadedBusinessCard(e) {
        $("#messageBusinessCard").hide();
        $("#file").css("color","green");
        $('#image_previewBusinessCard').css("display", "block");
        $('#previewingBusinessCard').attr('src', e.target.result);
        $('#previewingBusinessCard').attr('width', '50px');
        $('#previewingBusinessCard').attr('height', '50px');
    };
</script>
<?php $__env->stopPush(); ?>