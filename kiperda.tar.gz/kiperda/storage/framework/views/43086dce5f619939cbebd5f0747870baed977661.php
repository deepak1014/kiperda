<?php $__env->startSection('heading'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <table class="table table-hover " id="vendors-table">
   <a href="<?php echo route('vendors.create'); ?>" class="btn btn-primary pull-right" role="button">Create New Vendor</a>
   <h2>All Vendors</h2><br/>
        <thead>
            <tr>
                
                <th><?php echo app('translator')->get('vendor.headers.name'); ?></th>
                <th><?php echo app('translator')->get('vendor.headers.email'); ?></th>
                <th><?php echo app('translator')->get('vendor.headers.contact_number'); ?></th>
                <th><?php echo app('translator')->get('vendor.headers.status'); ?></th>
                <th></th>
                <th></th>
            </tr>
        </thead>
    </table>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(function() {
    $('#vendors-table').DataTable({
        processing: true,
        serverSide: true,
       
        ajax: '<?php echo route('vendors.data'); ?>',
        columns: [
            
            { data: 'namelink', name: 'name' },
            { data: 'email', name: 'email' },
            { data: 'contact_number', name: 'contact_number' },
            
            { data: 'status', name: 'status', orderable: false, searchable: false},
             <?php if(Entrust::can('vendor-update')): ?> 
            { data: 'edit', name: 'edit', orderable: false, searchable: false}
            <?php endif; ?>
           
        ]
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>