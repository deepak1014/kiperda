<div class="form-group">
    <?php echo Form::label('name', Lang::get('company.headers.name'), ['class' => 'control-label']); ?>

    <?php echo Form::text('name', null,['class' => 'form-control']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('active', Lang::get('company.headers.active'), ['class' => 'control-label']); ?>

<!--    <?php echo Form::checkbox('is_group', 1,['class' => 'form-control'],['autocomplete' => 'off']); ?>-->
<?php echo e(Form::checkbox('is_group', '1')); ?>

</div>
<div class="input_fields_wrap">
    <button class="add_field_button">Add More Fields</button>
    <?php if(count($items)>0): ?>  
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <div class="form-group">
    <?php echo Form::label('address', Lang::get('company.headers.address'), ['class' => 'control-label']); ?>

    <?php echo Form::text('address[]', $item->address_line_1,['class' => 'form-control'],['id' => 'txtPlaces']); ?>

    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
<?php else: ?>
    <div class="form-group">
    <?php echo Form::label('address', Lang::get('company.headers.address'), ['class' => 'control-label']); ?>

    <?php echo Form::text('address[]', null,['class' => 'form-control']); ?>

    </div>
<?php endif; ?>

</div>

<div class="form-group">
    <?php echo Form::label('mail', Lang::get('company.headers.mail'), ['class' => 'control-label']); ?>

   &nbsp; &nbsp; <?php echo Form::text('email', null,['class' => 'form-control']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('contact_number', Lang::get('company.headers.contact_number'), ['class' => 'control-label']); ?>

    <?php echo Form::text('contact_number', null,['class' => 'form-control']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('alternate_contact_number', Lang::get('company.headers.alternate_contact_number'), ['class' => 'control-label']); ?>

    <?php echo Form::text('alternate_contact_number', null,['class' => 'form-control']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('website', Lang::get('company.headers.website'), ['class' => 'control-label']); ?>

    <?php echo Form::text('website', null,['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('logo_path', Lang::get('company.headers.logo_path'), ['class' => 'control-label']); ?>

    <?php echo Form::file('logo_path', null,['class' => 'form-control']); ?>


</div>



<div class="form-group">
<?php echo e(Form::select('is_group', $itemsisgroup, $selectedCompanie,['class' => 'form-control'])); ?>

    
<!--    <select name="group_id" class = "form-control">
       <?php $__currentLoopData = $itemsisgroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemsvalue): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?> 
       <option value="<?php echo e($itemsvalue->id); ?>" <?php echo e($selectedCompanie == $itemsvalue->id ? 'selected=selected' : ''); ?>><?php echo e($itemsvalue->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
       
    </select>-->
</div>

<div class="form-group">
    <?php echo Form::label('type', Lang::get('company.headers.type'), ['class' => 'control-label']); ?><br>
    <select name="type" class = "form-control">
       <?php $__currentLoopData = $companyclassification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemsvalue): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?> 
       <option value="<?php echo e($itemsvalue->classification_name); ?>" <?php echo e($type == $itemsvalue->classification_name ? 'selected=selected' : ''); ?>><?php echo e($itemsvalue->classification_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
     </select>
</div>
<!--
Company, LLP, LLC, Corporation, Partnership, Sole
Proprietorship, Public Limited Company and Individual-->


<div class="form-group">
    <?php echo Form::label('currency', Lang::get('company.headers.currencyname'), ['class' => 'control-label']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('currency', Lang::get('company.headers.currency'), ['class' => 'control-label']); ?>

    <?php echo Form::radio('currency', 'USD',['class' => 'form-control']); ?>

    
    <?php echo Form::label('currency', Lang::get('company.headers.currency1'), ['class' => 'control-label']); ?>

    <?php echo Form::radio('currency', 'EURO',['class' => 'form-control']); ?>

</div>


<!--<?php echo e(Form::radio('sex', 'male')); ?><br>
<?php echo e(Form::radio('sex', 'female')); ?>-->


<?php echo Form::submit(Lang::get('company.headers.add_new'), ['class' => 'btn btn-primary']); ?>




		



