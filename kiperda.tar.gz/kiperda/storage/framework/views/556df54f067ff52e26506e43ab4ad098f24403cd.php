<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <title>Flarepoint CRM</title>
   <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script type="text/javascript" src="<?php echo e(URL::asset('js/trademark.js')); ?>"></script>
  <link href="<?php echo e(URL::asset('css/trademark.css')); ?>" rel="stylesheet" type="text/css" >
<script type="text/javascript">
function findClientid(id)
{
     $.ajax({
        url:'/trademark/getid/'+id,
        data:{'id':id},
       success: function(response)
    {
      console.log(response);
        /* $("#sub").show();
       $("#sub").html(response);*/
    }


    });


}
</script>
</head>
  
 
  


 <div style="height:40px;"></div>
    <div class="assessment-container container">
        <div class="row">
            <div class="col-md-6 form-box">
                


                <form action="<?php echo e(url('trademarksubtype')); ?>" id="trademark_sub_type" role="form" class="registration-form" action="javascript:void(0);">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <!--..first fieldset start..--> 
                    <fieldset id="box-1">
                    <?php $__currentLoopData = $companydocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <?php echo e($value->documenttypename); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?> 
                        <div class="form-top">
                            <div class="form-top-left">
                                <h3><span><i class="fa fa-trademark" aria-hidden="true"></i>
</span> &nbsp Create Record</h3>
<p>all(<span class="required"></span>) fields are mandatory</p>  

                                                            </div>
                        </div>
                        <div class="form-bottom">
                            <div class="row">
                                <div class="form-group">
                               <?php echo e(Form::label('email', 'Trademark Name')); ?>

                                   <?php echo e(Form::text('trademark_name','',['class'=>'form-control'])); ?>

                                </div>
                                

                               
                                    


                                <div class="form-group">
                                    <select name="trademarktype" class="form-control" id="trademark_type" onChange="findTrademarkType(this.value)">
                                    <option>Trademark Type</option>
                                    <?php $__currentLoopData = $trademarktype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <option value="<?php echo e($value->id); ?>"><?php echo e($value->type_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    </select>
                    
                                </div>
                                 <!--  <span id="sub" style="display:none;">
                               
                                    </span> -->
                                
                                 <div class="form-group">
                                    <select name="services" class="form-control" id="services" onChange="findSubServiceType(this.value)">
                                    <option>Select A Service</option>
                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <option value="<?php echo e($value->id); ?>"><?php echo e($value->service_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    </select>
                    
                                </div>

                                 <span id="subservicetype" style="display:none;">
                               
                                    </span>

                               
                               <div class="form-group">
                                    <select name="company" class="form-control" onChange="findClientid(this.value)">
                                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <option>Select Client</option>
                                    <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                   
                                </div>
                                <div class="form-group">                          
                                      <select name="country" class="form-control">
                                        <option>Select Country</option>
                                        <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <option value="<?php echo e($value->country_name); ?>" ><?php echo e($value->country_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                     </select> 
                                </div>
                                <div class="form-group">     
                                      <select name="trademarkstatus" class="form-control">
                                      <option>Select Trademark Status</option>
                                      <option value="abandoned">Anandoned</option>
                                      <option value="casetransferred">Case Transferred</option>
                                      <option value="cautionarynotice">Cautionary Notice</option>
                                      <option value="commonlawmark">Common Low Mark</option>               
                                      <option value="lapsed">Lapsed</option>               
                                      <option value="notyetfiled">Not Yet Filed</option>               
                                      <option value="pending">Pending</option>               
                                      <option value="refused">Refused</option>               
                                      <option value="registered">Registered</option>               
                                      <option value="test">Test</option>               
                                      <option value="withdrawn">Withdrawn</option>               
                                     </select>
                                 </div>       
                            <div class="form-group">
                           <select name="user" class="form-control">
                           <option>Select Supervisor/Action Attorney</option>
                           
                           <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                           <option value="<?php echo e($value->username); ?>"><?php echo e($value->username); ?></option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                           </select>
                            </div>
                             <div class="form-group">
                                    <input type="text" id="datepicker_1" class="form-control" placeholder="Instruction Date" required>
                                </div>
                            <input type="submit" name="submit" value="insert">
                            <button type="button" class="btn btn-next" id="next_1">Next</button>
                        </div>
                    </fieldset>
                    </form>


                    
</div>

                                   
            </div>
        </div>
    </div>