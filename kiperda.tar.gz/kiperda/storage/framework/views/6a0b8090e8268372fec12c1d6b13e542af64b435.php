<?php $__env->startSection('heading'); ?>
<h1><?php echo app('translator')->get('company.titles.all'); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

   <table  width="100%" >
         <tr>
                <th align="right"> <a href="<?php echo e(route('companies.create')); ?>"><button class="btn btn-primary pull-right"><?php echo app('translator')->get('Add New'); ?></button></a></th>
               
            </tr>
         <tr>
                <th align="right" height="10">&nbsp; </th>
               
            </tr>
       </table>
   <table class="table table-hover " id="company-table">
     
        <thead>
            <tr>
                <th><?php echo app('translator')->get('company.headers.name'); ?></th>
                <th><?php echo app('translator')->get('company.headers.mail'); ?></th>
                <th><?php echo app('translator')->get('company.headers.contact_number'); ?></th>
                <th><?php echo app('translator')->get('company.headers.edit'); ?></th>                
                <th><?php echo app('translator')->get('company.headers.delete'); ?></th>                
                <th><?php echo app('translator')->get('company.headers.status'); ?></th>
            </tr>
        </thead>
    </table>
  
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(function() {
    $('#company-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: '<?php echo route('companies.data'); ?>',
        columns: [
            
            { data: 'namelink', name: 'name' },
            { data: 'email', name: 'email' },
            { data: 'contact_number', name: 'contact_number' },
            <?php if(Entrust::can('company-update')): ?>  
            {data: 'edit', name: 'edit', orderable: false, searchable: false  },
            { data: 'delete', name: 'delete', orderable: false, searchable: false},
            { data: 'status', name: 'status' },
            <?php endif; ?>      
        ]
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>