<html>
<head><title></title>
<script>
$(document).ready(function() {
    var max_fields      = 10; //maximum input boxes allowed
    var wrapper         = $(".input_fields_wrap"); //Fields wrapper
    var add_button      = $(".add_field_button"); //Add button ID
   
    var x = 1; //initlal text box count
    $(add_button).click(function(e){ //on add input button click
        e.preventDefault();
        if(x < max_fields){ //max input box allowed
            x++; //text box increment
            $(wrapper).append('<div class="col-sm-6"> <?php echo Form::label('address', 'Address:', ['class' => 'control-label required']); ?><input type="text" class="form-control" name="address[]"/><a href="#" class="remove_field">Remove</a></div>'); //add input box
        }
    });
   
    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
        e.preventDefault(); $(this).parent('div').remove(); x--;
    })
});
</script>
</head>
<div class="form-inline">
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Name:', ['class' => 'control-label required']); ?>

    <?php echo Form::text('name',  
        isset($data['name']) ? $data['name'][0]['name'] : null, 
        ['class' => 'form-control']); ?>

</div>
<div class="input_fields_wrap">
<?php if(count($items)): ?>

<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>


 <div class="form-group col-sm-6">

        <?php echo Form::label('address', 'Address:', ['class' => 'control-label required']); ?>

    <?php echo Form::text('address[]',
        isset($data['address[]']) ? $data['address[]'] : $item->address, 
        ['class' => 'form-control']); ?>

    
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
<button class="add_field_button pull-right">Add More Address</button>
<?php else: ?>

<div class="form-group col-sm-6">

        <?php echo Form::label('address', 'Address:', ['class' => 'control-label required']); ?><button class="add_field_button pull-right">Add More Address</button>
    <?php echo Form::text('address[]',
        isset($data['address[]']) ? $data['address[]'] : null, 
        ['class' => 'form-control']); ?>

    
</div>
<?php endif; ?>



</div>
 </div>

<div class="form-group col-sm-6">
        <?php echo Form::label('email', 'Email:', ['class' => 'control-label required']); ?>

    <?php echo Form::email('email',
        isset($data['email']) ? $data['email'] : null, 
        ['class' => 'form-control']); ?>

</div>
<div class="form-group col-sm-6">
        <?php echo Form::label('contact_number', 'Contact Number:', ['class' => 'control-label required']); ?>

        <?php echo Form::text('contact_number',
            isset($data['contact_number']) ? $data['contact_number'] : null, 
            ['class' => 'form-control']); ?>

</div>  
 <div class="form-group col-sm-6">
        <?php echo Form::label('mobile_number', 'Mobile Number:', ['class' => 'control-label required']); ?>

        <?php echo Form::text('mobile_number',
            isset($data['mobile_number']) ? $data['mobile_number'] : null, 
            ['class' => 'form-control']); ?>

</div>  
    <div class="form-group col-sm-6">
        <?php echo Form::label('organization_name', 'Organization Name:', ['class' => 'control-label required']); ?>

        <?php echo Form::text('organization_name',
            isset($data['organization_name']) ? $data['organization_name'] : null, 
            ['class' => 'form-control']); ?>

    </div>  
  <div class="form-group col-sm-6">
    <?php echo Form::label('country', 'Country:', ['class' => 'control-label']); ?> 
    <select name="country" class="form-control">
    <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <option value="<?php echo e($value->country_name); ?>" <?php echo e($value->country_name==$countryvalue ? 'selected=selected':''); ?>><?php echo e($value->country_name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

    </select> 
</div>
     <div class="form-group col-sm-6">
        <?php echo Form::label('city', 'City:', ['class' => 'control-label required']); ?>

        <?php echo Form::text('city',
            isset($data['city']) ? $data['city'] : null, 
            ['class' => 'form-control']); ?>

    </div>  
    <div class="form-group col-sm-6">
        <?php echo Form::label('pincode', 'Pincode:', ['class' => 'control-label required']); ?>

        <?php echo Form::text('pincode',
            isset($data['pincode']) ? $data['pincode'] : null, 
            ['class' => 'form-control']); ?>

    </div>  
    <div class="form-group col-sm-6">
        <?php echo Form::label('fax_telephone', 'Fax/Telephone:', ['class' => 'control-label required']); ?>

        <?php echo Form::text('fax_telephone',
            isset($data['fax_telephone']) ? $data['fax_telephone'] : null, 
            ['class' => 'form-control']); ?>

    </div>  
    
    <div class="form-group col-sm-6">
        <?php echo Form::label('vendor_code', 'Vendor Code:', ['class' => 'control-label required']); ?>

        <?php echo Form::text('vendor_code',
            isset($data['vendor_code']) ? $data['vendor_code'] : null, 
            ['class' => 'form-control']); ?>

    </div>  
     <div class="form-group col-sm-6">
        <?php echo Form::label('kipg_associate_code', 'Kipg Associate Code:', ['class' => 'control-label required']); ?>

        <?php echo Form::text('kipg_associate_code',
            isset($data['kipg_associate_code']) ? $data['kipg_associate_code'] : null, 
            ['class' => 'form-control']); ?>

    </div>  
    <div class="form-group col-sm-6">
        <?php echo Form::label('preferred_vendor', 'Preferred Vendor:', ['class' => 'control-label required']); ?>

        <?php echo Form::text('preferred_vendor',
            isset($data['preferred_vendor']) ? $data['preferred_vendor'] : null, 
            ['class' => 'form-control']); ?>

    </div>  
    <div class="form-group col-sm-6">
        <?php echo Form::label('currency', 'Currency:', ['class' => 'control-label required']); ?>

         <?php echo Form::radio('currency','USD',['class'=>'form-control']); ?>USD   
         <?php echo Form::radio('currency','EURO',['class'=>'form-control']); ?>EURO   



    </div>  
    
     <div class="form-group col-sm-6">
       <?php echo e(Form::label('image', Lang::get('vendor.headers.image'), ['class' => 'control-label'])); ?>

    <?php echo Form::file('image',  null, ['class' => 'form-control']); ?>

    </div>  







<?php echo Form::submit($submitButtonText, ['class' => 'btn btn-primary']); ?>