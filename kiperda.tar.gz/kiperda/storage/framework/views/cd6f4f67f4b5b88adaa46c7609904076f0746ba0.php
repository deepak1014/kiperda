<?php $__env->startSection('heading'); ?>

<h1><?php echo app('translator')->get('company.titles.edit'); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<script>
$(document).ready(function() {
    var max_fields      = 10; //maximum input boxes allowed
    var wrapper         = $(".input_fields_wrap"); //Fields wrapper
    var add_button      = $(".add_field_button"); //Add button ID
   
    var x = 1; //initlal text box count
    $(add_button).click(function(e){ //on add input button click
        e.preventDefault();
        if(x < max_fields){ //max input box allowed
            x++; //text box increment
            $(wrapper).append('<div><input type="text" name="mytext[]" class="form-control"/><a href="#" class="remove_field">Remove</a></div>'); //add input box
        }
    });
   
    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
        e.preventDefault(); $(this).parent('div').remove(); x--;
    })
});
            
</script> 

<?php echo Form::model($companies, [
        'method' => 'PATCH',
        'route' => ['companies.update', $companies->id],
        'files'=>true,
        'enctype' => 'multipart/form-data'
        ]); ?>

        
<?php echo $__env->make('companies.form', ['submitButtonText' => Lang::get('companies.headers.update_submit')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>