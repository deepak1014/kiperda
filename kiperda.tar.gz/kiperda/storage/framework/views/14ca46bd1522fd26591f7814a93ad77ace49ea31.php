<?php $__env->startSection('heading'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
});


</script>

<div class="row">
<?php echo $__env->make('partials.clientheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('partials.userheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</div>

     <div class="row">
        <div class="col-md-9">
          <div class="taskcase">

          <h3><?php echo e($tasks->title); ?></h3>
          <hr class="grey">
          <p><?php echo e($tasks->description); ?></p>
          <p class="smalltext"><?php echo app('translator')->get('task.headers.created_at'); ?>: 
          <?php echo e(date('d F, Y, H:i:s', strtotime($tasks->created_at))); ?> 
          <?php if($tasks->updated_at != $tasks->created_at): ?> 
          <br/><?php echo app('translator')->get('task.status.modified'); ?>: <?php echo e(date('d F, Y, H:i:s', strtotime($tasks->updated_at))); ?>

          <?php endif; ?></p>
          

              
      </div>
    
          <?php $count = 0;?>

           <?php $i=1 ?>
          <?php $__currentLoopData = $tasks->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <div class="taskcase" style="margin-top:15px; padding-top:10px;">
                  <p  class="smalltext">#<?php echo e($i++); ?></p>
                  <p>  <?php echo e($comment->description); ?></p>
                  <p class="smalltext"><?php echo app('translator')->get('task.titles.comment_by'); ?>: <a href="<?php echo e(route('users.show', $comment->user->id)); ?>"> <?php echo e($comment->user->name); ?> </a></p>
                            <p class="smalltext"><?php echo app('translator')->get('task.headers.created_at'); ?>: 
          <?php echo e(date('d F, Y, H:i:s', strtotime($comment->created_at))); ?> 
          <?php if($comment->updated_at != $comment->created_at): ?> 
          <br/><?php echo app('translator')->get('task.status.modified'); ?>: <?php echo e(date('d F, Y, H:i:s', strtotime($comment->updated_at))); ?>

          <?php endif; ?></p>
                  </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
  <br />
         <?php echo Form::open(array('url' => array('/tasks/comments',$tasks->id, ))); ?>

          <div class="form-group">
    <?php echo Form::textarea('description', null, ['class' => 'form-control']); ?>

    
    <?php echo Form::submit(Lang::get('task.titles.add_comment'), ['class' => 'btn btn-primary']); ?>

</div>
        <?php echo Form::close(); ?>


          </div>
          <div class="col-md-3">
          <div class="sidebarheader">
            <p><?php echo app('translator')->get('task.titles.task_information'); ?></p>
             </div>
          <div class="sidebarbox">
            <p><?php echo app('translator')->get('task.headers.assigned'); ?>:
            <a href="<?php echo e(route('users.show', $tasks->assignee->id)); ?>">
             <?php echo e($tasks->assignee->name); ?></a></p>
            <p><?php echo app('translator')->get('task.headers.created_at'); ?>: <?php echo e(date('d F, Y, H:i', strtotime($tasks->created_at))); ?> </p>
           
            <?php if($tasks->days_until_deadline): ?>
             <p ><?php echo app('translator')->get('task.headers.deadline'); ?>: <span style="color:red;"><?php echo e(date('d, F Y', strTotime($tasks->deadline))); ?>


              <?php if($tasks->status == 1): ?>(<?php echo $tasks->days_until_deadline; ?>)<?php endif; ?></span></p><!--Remove days left if tasks is completed-->

             <?php else: ?>
             <p ><?php echo app('translator')->get('task.headers.deadline'); ?>: <span style="color:green;"><?php echo e(date('d, F Y', strTotime($tasks->deadline))); ?>


             <?php if($tasks->status == 1): ?>(<?php echo $tasks->days_until_deadline; ?>)<?php endif; ?></span></p> <!--Remove days left if tasks is completed-->
             <?php endif; ?>
       
            <?php if($tasks->status == 1): ?>
            <?php echo app('translator')->get('task.headers.status'); ?>: Open
            <?php else: ?>
            <?php echo app('translator')->get('task.headers.status'); ?>: Closed
            <?php endif; ?>
            </div>   
            <?php if($tasks->status == 1): ?>

          <?php echo Form::model($tasks, [
         'method' => 'PATCH',
          'url' => ['tasks/updateassign', $tasks->id],
          ]); ?>

           <?php echo Form::select('fk_user_id_assign', $users, null, ['class' => 'form-control ui search selection top right pointing search-select', 'id' => 'search-select']); ?>

          <?php echo Form::submit(Lang::get('task.titles.assign_user'), ['class' => 'btn btn-primary form-control closebtn']); ?>

       <?php echo Form::close(); ?>


                <?php echo Form::model($tasks, [
          'method' => 'PATCH',
          'url' => ['tasks/updatestatus', $tasks->id],
          ]); ?>

            
          <?php echo Form::submit(Lang::get('task.titles.close_task'), ['class' => 'btn btn-success form-control closebtn']); ?>

       <?php echo Form::close(); ?>


            <?php endif; ?>
             <div class="sidebarheader">
            <p><?php echo app('translator')->get('task.invoices.time_managment'); ?></p>
            </div>
         <table class="table table_wrapper ">
           <tr>
             <th><?php echo app('translator')->get('task.invoices.title'); ?></th>
             <th><?php echo app('translator')->get('task.invoices.time'); ?></th>
           </tr>
           <tbody>
            <?php $__currentLoopData = $tasktimes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tasktime): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>
             <td style="padding: 5px"><?php echo e($tasktime->title); ?></td> 
             <td style="padding: 5px"><?php echo e($tasktime->time); ?> </td>
             </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
           </tbody>
         </table>
  <br/>
       <button type="button" class="btn btn-primary form-control" data-toggle="modal" data-target="#ModalTimer">
  <?php echo app('translator')->get('task.invoices.add_time'); ?>
</button>

       <button type="button" class="btn btn-primary form-control movedown" data-toggle="modal" data-target="#myModal">
  <?php echo app('translator')->get('task.invoices.create'); ?>
</button>

<div class="activity-feed movedown">
          <?php $__currentLoopData = $tasks->activity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <div class="feed-item">
          <div class="activity-date"><?php echo e(date('d, F Y H:i', strTotime($activity->created_at))); ?></div>
             <div class="activity-text"><?php echo e($activity->text); ?></div>
                
                </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>
<div class="modal fade" id="ModalTimer" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><?php echo app('translator')->get('task.invoices.modal.header_title'); ?>  (<?php echo e($tasks->title); ?>)</h4>
      </div>

      <div class="modal-body">
      
          <?php echo Form::open([
          'method' => 'post',
          'url' => ['tasks/updatetime', $tasks->id],
          ]); ?>


<div class="form-group">
    <?php echo Form::label('title', Lang::get('task.invoices.modal.title'), ['class' => 'control-label']); ?>

    <?php echo Form::text('title', null, ['class' => 'form-control', 'placeholder' =>  Lang::get('task.invoices.modal.title_placerholder')]); ?>

</div>
<div class="form-group">
    <?php echo Form::label('comment',  Lang::get('task.invoices.modal.description'), ['class' => 'control-label']); ?>

    <?php echo Form::textarea('comment', null, ['class' => 'form-control', 'placeholder' => Lang::get('task.invoices.modal.description_placerholder')]); ?>

</div>
<div class="form-group">
    <?php echo Form::label('value', Lang::get('task.invoices.modal.hourly_price'), ['class' => 'control-label']); ?>

    <?php echo Form::text('value', null, ['class' => 'form-control', 'placeholder' => '300']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('time', Lang::get('task.invoices.modal.time_spend'), ['class' => 'control-label']); ?>

    <?php echo Form::text('time', null, ['class' => 'form-control', 'placeholder' => '3']); ?>

</div>
    


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default col-lg-6" data-dismiss="modal"><?php echo app('translator')->get('task.invoices.modal.close'); ?></button>
    <div class="col-lg-6">
        <?php echo Form::submit(Lang::get('task.invoices.modal.register_time'), ['class' => 'btn btn-success form-control closebtn']); ?>

        </div>
       <?php echo Form::close(); ?>

      </div>
    </div>
  </div>
</div>




<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><?php echo app('translator')->get('task.invoices.create'); ?> </h4>
      </div>

      <div class="modal-body">

               <?php echo Form::model($tasks, [
          'method' => 'POST',
          'url' => ['tasks/invoice', $tasks->id],
          ]); ?>

     <?php if($apiconnected): ?>     
               <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $contact): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <?php echo Form::radio('invoiceContact', $contact['guid']); ?>

        <?php echo e($contact['name']); ?>

    <br />
  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            <?php echo Form::label('mail', 'Send mail with invoice to Customer?(Cheked = Yes):', ['class' => 'control-label']); ?>

        <?php echo Form::checkbox('sendMail', true); ?>

               <?php endif; ?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default col-lg-6" data-dismiss="modal"><?php echo app('translator')->get('task.invoices.modal.close'); ?></button>
    <div class="col-lg-6">
        <?php echo Form::submit(Lang::get('task.invoices.create'), ['class' => 'btn btn-success form-control closebtn']); ?>

        </div>
       <?php echo Form::close(); ?>


      </div>
    </div>
  </div>
</div>


             </div>
         
            </div> 
          </div>

        </div>


     
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>