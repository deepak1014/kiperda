<form role="form" class="registration-form" action="javascript:void(0);">
                    <fieldset style="display:none;" id="box-2">
                                <h2 style="font-family:Courier New, Courier, monospace;">Registration Details</h2>
                                 <hr>


                            <div class="row">
                                <div class="form-group col-sm-6">
                                    <input type="text" name="application_number" placeholder="Application Number" class="form-control form-control" id="application_number" required>
                                </div>
                                <div class="form-group col-sm-6">
                                    <input type="text" id="datepicker_2" class="form-control" placeholder="Application Date" required>
                                </div>
                                <div class="form-group col-sm-6">
                                    <input type="text" id="registration_number" class="form-control" placeholder="Registration Number" required>
                                </div>
                                <div class="form-group col-sm-6">
                                    <input type="text" id="datepicker_3" class="form-control" placeholder="Registration Date" required>
                                </div>
                                <div class="form-group col-sm-6">
                                    <input type="text" id="datepicker" class="form-control" placeholder="Associate KIPG Code" required>
                                </div>
                                <div class="form-group col-sm-6">
                                    <input type="text" id="datepicker" class="form-control" placeholder="Associate Ref Code (Vendor/Client Number)" required>
                                </div>
                                <div class="form-group col-sm-6">
                                    <input type="text" id="datepicker" class="form-control" placeholder="Matter Sub-Service Selected" required>
                                </div>
                                <div class="form-group col-sm-6">
                                    <input type="text" id="datepicker" class="form-control" placeholder="Jurisdiction" required>
                                </div>
                              
                                <div class="form-group col-sm-6">
                                    <input type="text" name="trademark_region" placeholder="Trademark Region" class="form-control" id="trademark_region" required>
                                </div>
                                
                                <div class="form-group col-sm-6">
                                    <input type="text" id="device_clarification" class="form-control" placeholder="Device Clarification" required>
                                </div>
                                 <div class="form-group col-sm-6">
                                    <select name="color_claim" class="form-control">
                                    <option>Color Claim</option>
                                    <option value="yes">Yes</option>
                                    <option value="no">No</option>
                                    </select>
                                </div>
                                <div class="form-group col-sm-6">
                                    <input type="text" id="classes" class="form-control" placeholder="Classes" required>
                                </div>
                                <div class="form-group col-sm-6">
                                    <input type="text" id="priority_application_number" class="form-control" placeholder="Priority Application Number" required>
                                </div>
                                <div class="form-group col-sm-6">
                                    <select name="entity_nature" class="form-control">
                                    <option>Entity Nature</option>
                                    <?php $__currentLoopData = $company_classification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <option value="<?php echo e($value->classification_name); ?>"><?php echo e($value->classification_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    </select>
                                </div>
                                 <div class="form-group col-sm-6">
                                   <select name="country" class="form-control">
                                   <option>Country Of Incorporation</option>
                                        <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <option value="<?php echo e($value->country_name); ?>" ><?php echo e($value->country_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                     </select> 
                                </div>
                                 <div class="form-group col-sm-6">
                                    <input type="text" id="vendor_instruction" class="form-control" placeholder="Vendor Instruction" required>
                                </div>
                                <div class="form-group col-sm-6">
                                    <input type="text" id="datepicker_4" class="form-control" placeholder="Due Date" required>
                                </div>
                                <div class="form-group col-sm-6">
                                    <input type="text" id="datepicker_5" class="form-control" placeholder="Filing Date" required>
                                </div>
                               
                                
                            </div>
                            <!-- </div> -->
                        <!-- <div class="form-bottom"> -->
                           
                            <button type="button" class="btn btn-previous" id="previous_1">Previous</button>
                            <button type="button" class="btn btn-next" id="next_2">Next</button>
                            


                    </fieldset>
                   
                    
<html>  
<head><title></title>
<script>
$(document).ready(function() {
    var max_fields      = 10; //maximum input boxes allowed
    var wrapper         = $(".input_fields_wrap"); //Fields wrapper
    var add_button      = $(".add_field_button"); //Add button ID
   
    var x = 1; //initlal text box count
    $(add_button).click(function(e){ //on add input button click
        e.preventDefault();
        if(x < max_fields){ //max input box allowed
            x++; //text box increment
            $(wrapper).append('<table id="a" border="2px"><tr><td><input type="file" name="image" class="form-control"></td><td><select name="company_documents" class="form-control"><?php $__currentLoopData = $companydocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?><option value="<?php echo e($value->id); ?>"><?php echo e($value->documenttypename); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?> </select></td><td><input type="text" name="image" placeholder="Comment" class="form-control"><a href="#" class="remove_field">Remove</a></td></table>'); 
                
            //add input box
        }
    });
   
    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
        e.preventDefault(); $(this).parents('#a').remove(); x--;
    })
});
</script>
</head>


<fieldset  id="box-3">
                    
                            <div class="row">
                           
                               <div class="form-group col-sm-6">
                                  <input type="text" id="transliteration" class="form-control" placeholder="Transliteration" required>
                                </div>
                                <div class="form-group col-sm-6">
                                    <input type="text" id="datepicker_6" class="form-control" placeholder="Action Date" required>
                                </div>
                                <div class="form-group col-sm-6">
                                    <input type="text" id="datepicker_7" class="form-control" placeholder="Final Action Date" required>
                                </div>
                                <div class="form-group col-sm-6">
                                    <input type="text" id="renewal_due" class="form-control" placeholder="Renewal Due" required>
                                </div>
                                <div class="form-group col-sm-6">
                                    <input type="text" id="translation" class="form-control" placeholder="Translation" required>
                                </div>
                              
                      
                                <div class="form-group col-sm-6">
                                    <input type="text" id="datepicker_8" name="document_sent_by_client_date" class="form-control" placeholder="Document Sent By Client (Date)" required>
                                </div>
                 
                            
                                <div class="form-group col-sm-6">
                                    <input type="text" id="vienna_code" class="form-control" placeholder="Vienna Code" required>
                                </div>
                               
                                <div class="form-group col-sm-6">
                                    <input type="text" id="foreign_characters" class="form-control" placeholder="Foreign Characters" required>
                                </div>
                                <div class="form-group col-sm-6">
                                    <input type="text" id="disclaimer" class="form-control" placeholder="Disclaimer" required>
                                </div>
                                <div class="form-group col-sm-6">
                                    <input type="text" id="specification" class="form-control" placeholder="Specification (Goods & Services)" required>
                                </div>
                                
                                
                                <div class="form-group col-sm-6">
                                  <input type="text" id="received_by_email_post" class="form-control" placeholder="Received On By Email/Post" required>
                                </div>
                                 <div class="form-group col-sm-6">
                                    <input type="text" id="datepicker_9" name="document_dispatch_date" class="form-control" placeholder="Document Dispatch Date" required>
                                </div>
                             
                                 <div class="form-group col-sm-6">
                                   
                                    <input type="text" id="dispatched_by_email_post" name="dispatched_by_email_post" class="form-control" placeholder="Dispatched By Email/Post" required>
                                </div>
                                <div class="form-group col-sm-6">
                                    <input type="text" id="foreign_characters" class="form-control" placeholder="Foreign Characters" required>
                                </div>
                                <div class="form-group col-sm-6">
                                    <input type="text" id="disclaimer" class="form-control" placeholder="Disclaimer" required>
                                </div>
                                <div class="form-group col-sm-6">
                                    <input type="text" id="specification" class="form-control" placeholder="Specification (Goods & Services)" required>
                                </div>
                                <div class="form-group col-sm-6">
                                    <input type="file" name="image" class="form-control">
                                </div>
                                <div class="form-group col-sm-6">
                                    <input type="file" name="image" class="form-control">
                                </div>
                                 <div class="form-group col-sm-6">
                                    <input type="file" name="image" class="form-control" >
                                </div>

                              </div>
                              
                        <button type="button" class="btn btn-previous" id="previous_2">Previous</button> 
                        <button type="button" class="btn btn-next" id="next_3">Next</button>
                        
                        </div>  
                    </fieldset>
 
                              </div>

                              
                <fieldset style="display:none;"  id="box-4">
                            <h2 style="font-family:Courier New, Courier, monospace;">Upload Document</h2>
                            




                            
                    <div class="input_fields_wrap">


                    <?php if(count($companydocuments)): ?>

 

                            <table border="2px">
                                <tr>
                                    <td><input type="file" name="image" class="form-control"></td>
                                    <td> <select name="company_documents" class="form-control">
                                        <option>Document Type</option>
                                        <?php $__currentLoopData = $companydocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <option value="<?php echo e($value->id); ?>"><?php echo e($value->documenttypename); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                        </select>
                                    </td>
                                    <td>
                                        <input type="text" id="specification" placeholder="Comment" required>
                                    </td>
                                    </tr>
                                    </table>

                <button type="button" class="btn btn-previous" id="previous_3">Previous</button> 
                <button type="button" class="btn btn-next" id="next_4">Next</button>
                        
                <button class="add_field_button btn btn-primary">Upload More Document</button>
                <?php else: ?>

                
                <?php endif; ?>





                                
                                       


                    </fieldset>


                            <fieldset style="display:none;"  id="box-5">
                            <h2 style="font-family:Courier New, Courier, monospace;">Verify Checklist</h2>
                    

                <button type="button" class="btn btn-previous" id="previous_4">Previous</button> 
                <button type="button" class="btn btn-next" id="next_5">Next</button>
                        
                <button class="add_field_button btn btn-primary">Upload More Document</button>
                                       


                    </fieldset>

     
                                
                                
                       
                            <fieldset style="display:none;"  id="box-5">
                            <h2 style="font-family:Courier New, Courier, monospace;">Verify Checklist</h2>
                  

                <button type="button" class="btn btn-previous" id="previous_4">Previous</button> 
                <button type="button" class="btn btn-next" id="next_5">Next</button>
                        
                <button class="add_field_button btn btn-primary">Upload More Document</button>
                                       


                    </fieldset>

            
                      