<?php $__currentLoopData = $companydocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<?php echo e($value->company_id); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>