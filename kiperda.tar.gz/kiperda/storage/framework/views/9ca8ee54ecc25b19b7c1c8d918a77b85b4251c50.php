<?php $__env->startSection('heading'); ?>
<h1><?php echo app('translator')->get('client.titles.create'); ?></h1>
 <p>all(<span class="required"></span>) fields are mandatory</p>  

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo Form::open([
        'route' => 'vendors.store',
        'files'=>true,
        'enctype' => 'multipart/form-data'

        ]); ?>

<?php echo $__env->make('vendors.form', ['submitButtonText' => Lang::get('vendor.headers.create_submit')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>