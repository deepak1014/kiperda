<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <title>Flarepoint CRM</title>
   <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script type="text/javascript" src="<?php echo e(URL::asset('js/trademark.js')); ?>"></script>
  <link href="<?php echo e(URL::asset('css/trademark.css')); ?>" rel="stylesheet" type="text/css" >

</head>
  
 
  


 <div style="height:40px;"></div>
    <div class="assessment-container container">
        <div class="row">
            <div class="col-md-6 form-box">
                


                <form action="<?php echo e(url('trademarksubtype')); ?>" id="trademark_sub_type" role="form" class="registration-form" action="javascript:void(0);">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <!--..first fieldset start..--> 
                    <fieldset id="box-1">
                        <div class="form-top">
                            <div class="form-top-left">
                                <h3><span><i class="fa fa-trademark" aria-hidden="true"></i>
</span> &nbsp Create Record</h3>
<p>all(<span class="required"></span>) fields are mandatory</p>  

                                                            </div>
                        </div>
                        <div class="form-bottom">
                            <div class="row">
                                <div class="form-group">
                                    <input type="text" name="trademark_name" placeholder="Trademark Name" class="form-control form-control" id="trademark_name" required>
                                </div>
                                <div class="form-group">
                                    <select name="trademarktype" class="form-control" id="trademark_type" onChange="findTrademarkType(this.value)">
                                    <option>Trademark Type</option>
                                    <?php $__currentLoopData = $trademarktype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <option value="<?php echo e($value->id); ?>"><?php echo e($value->type_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    </select>
                    
                                </div>
                                  <span id="sub" style="display:none;">
                               
                                    </span>
                                
                                 <div class="form-group">
                                    <select name="trademarktype" class="form-control" id="trademark_type" onChange="findTrademarkType(this.value)">
                                    <option>Trademark Type</option>
                                    <?php $__currentLoopData = $trademarktype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <option value="<?php echo e($value->id); ?>"><?php echo e($value->type_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    </select>
                    
                                </div>



                               
                               <div class="form-group">
                                    <select name="company" class="form-control">
                                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <option>Select Client</option>
                                    <option value="<?php echo e($value->name); ?>"><?php echo e($value->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                   
                                </div>
                                <div class="form-group">                          
                                      <select name="country" class="form-control">
                                        <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <option>Select Country</option>
                                    <option value="<?php echo e($value->country_name); ?>" ><?php echo e($value->country_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                     </select> 
                                </div>
                                <div class="form-group">     
                                      <select name="trademarkstatus" class="form-control">
                                      <option>Select Trademark Status</option>
                                      <option value="abandoned">Anandoned</option>
                                      <option value="casetransferred">Case Transferred</option>
                                      <option value="cautionarynotice">Cautionary Notice</option>
                                      <option value="commonlawmark">Common Low Mark</option>               
                                      <option value="lapsed">Lapsed</option>               
                                      <option value="notyetfiled">Not Yet Filed</option>               
                                      <option value="pending">Pending</option>               
                                      <option value="refused">Refused</option>               
                                      <option value="registered">Registered</option>               
                                      <option value="test">Test</option>               
                                      <option value="withdrawn">Withdrawn</option>               
                                     </select>
                                 </div>       
                            <div class="form-group">
                           <select name="user" class="form-control">
                           <option>Select Supervisor/Action Attorney</option>
                           
                           <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                           <option value="<?php echo e($value->username); ?>"><?php echo e($value->username); ?></option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                           </select>
                            </div>
                             <div class="form-group">
                                    <input type="text" id="datepicker_1" class="form-control" placeholder="Instruction Date" required>
                                </div>
                            <input type="submit" name="submit" value="insert">
                            <button type="button" class="btn btn-next" id="next_1">Next</button>
                        </div>
                    </fieldset>
                    </form>
                    <form role="form" class="registration-form" action="javascript:void(0);">
                    <fieldset style="display:none;" id="box-2">
                     <div class="form-top">
                            <div class="form-top-left">
                                <h3><span><i class="fa fa-trademark" aria-hidden="true"></i>
</span> &nbsp Create Record</h3>
<p>all(<span class="required"></span>) fields are mandatory</p>  

                                                            </div>
                        </div>
                        <div class="form-bottom">
                            <div class="row">
                            <div class="form-group">
                                    <input type="text" name="application_number" placeholder="Application Number" class="form-control form-control" id="application_number" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="datepicker_2" class="form-control" placeholder="Application Date" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="registration_number" class="form-control" placeholder="Registration Number" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="datepicker_3" class="form-control" placeholder="Registration Date" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="datepicker" class="form-control" placeholder="Associate KIPG Code" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="datepicker" class="form-control" placeholder="Associate Ref Code (Vendor/Client Number)" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="datepicker" class="form-control" placeholder="Matter Sub-Service Selected" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="datepicker" class="form-control" placeholder="Jurisdiction" required>
                                </div>
                              </div>
                              
                        <button type="button" class="btn btn-previous" id="previous_1">Previous</button> 
                        <button type="button" class="btn btn-next" id="next_2">Next</button>
                        </div>  
                    </fieldset>

            <fieldset style="display:none;" id="box-3">
             <div class="form-top">
                            <div class="form-top-left">
                                <h3><span><i class="fa fa-trademark" aria-hidden="true"></i>
</span> &nbsp Create Record</h3>
<p>all(<span class="required"></span>) fields are mandatory</p>  

                                                            </div>
                        </div>
                        <div class="form-bottom">
                            <div class="row">
                             <div class="form-group">
                                    <input type="text" name="trademark_region" placeholder="Trademark Region" class="form-control" id="trademark_region" required>
                                </div>
                                <div class="form-group">
                                    <input type="file" name="image" class="form-control">
                                </div>
                                <div class="form-group">
                                <select name="type_of_trademark" class="form-control">
                                <option>Type Of Trademark</option>
                                <option value="conventional">Conventional</option>
                                <option value="non-conventional">Non Conventional</option>
                                </select>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="device_clarification" class="form-control" placeholder="Device Clarification" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="colors_claimed" class="form-control" placeholder="Colors Claimed" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="classes" class="form-control" placeholder="Classes" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="priority_application_number" class="form-control" placeholder="Priority Application Number" required>
                                </div>
                                <div class="form-group">
                                    <select name="entity_nature" class="form-control">
                                    <option>Entity Nature</option>
                                    <?php $__currentLoopData = $company_classification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <option value="<?php echo e($value->classification_name); ?>"><?php echo e($value->classification_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <!-- </div> -->
                        <!-- <div class="form-bottom"> -->
                           
                            <button type="button" class="btn btn-previous" id="previous_2">Previous</button>
                            <button type="button" class="btn btn-next" id="next_3">Next</button>
                            </div>
                        

                    </fieldset>

                    <fieldset style="display:none;" id="box-4">
                     <div class="form-top">
                            <div class="form-top-left">
                                <h3><span><i class="fa fa-trademark" aria-hidden="true"></i>
</span> &nbsp Create Record</h3>
<p>all(<span class="required"></span>) fields are mandatory</p>  

                                                            </div>
                        </div>
                         <div class="form-bottom">
                            <div class="row">
                            <div class="form-group">
                                   <select name="country" class="form-control">
                                   <option>Country Of Incorporation</option>
                                        <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <option value="<?php echo e($value->country_name); ?>" ><?php echo e($value->country_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                     </select> 
                                </div>
                                <div class="form-group">
                                    <input type="text" id="vendor_instruction" class="form-control" placeholder="Vendor Instruction" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="datepicker_4" class="form-control" placeholder="Due Date" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="datepicker_5" class="form-control" placeholder="Filing Date" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="datepicker_6" class="form-control" placeholder="Action Date" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="datepicker_7" class="form-control" placeholder="Final Action Date" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="renewal_due" class="form-control" placeholder="Renewal Due" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="translation" class="form-control" placeholder="Translation" required>
                                </div>
                              </div>
                              
                        <button type="button" class="btn btn-previous" id="previous_3">Previous</button> 
                        <button type="button" class="btn btn-next" id="next_4">Next</button>
                        </div>  
                    </fieldset>
                    <fieldset style="display:none;" id="box-5">
                     <div class="form-top">
                            <div class="form-top-left">
                                <h3><span><i class="fa fa-trademark" aria-hidden="true"></i>
</span> &nbsp Create Record</h3>
<p>all(<span class="required"></span>) fields are mandatory</p>  

                                                            </div>
                        </div>
                         <div class="form-bottom">
                            <div class="row">
                            <div class="form-group">
                                  <input type="text" id="transliteration" class="form-control" placeholder="Transliteration" required>
                                </div>
                                <div class="form-group">
                                    <input type="file" name="image">
                                </div>
                                <div class="form-group">
                                    <input type="text" id="vienna_code" class="form-control" placeholder="Vienna Code" required>
                                </div>
                                <div class="form-group">
                                    <select name="color_claim" class="form-control">
                                    <option>Color Claim</option>
                                    <option value="yes">Yes</option>
                                    <option value="no">No</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="foreign_characters" class="form-control" placeholder="Foreign Characters" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="disclaimer" class="form-control" placeholder="Disclaimer" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="specification" class="form-control" placeholder="Specification (Goods & Services)" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="datepicker_8" name="document_sent_by_client_date" class="form-control" placeholder="Document Sent By Client (Date)" required>
                                </div>
                              </div>
                              
                        <button type="button" class="btn btn-previous" id="previous_4">Previous</button> 
                        <button type="button" class="btn btn-next" id="next_5">Next</button>
                        </div>  
                    </fieldset>
<fieldset style="display:none;" id="box-6">
 <div class="form-top">
                            <div class="form-top-left">
                                <h3><span><i class="fa fa-trademark" aria-hidden="true"></i>
</span> &nbsp Create Record</h3>
<p>all(<span class="required"></span>) fields are mandatory</p>  

                                                            </div>
                        </div>
                         <div class="form-bottom">
                            <div class="row">
                            <div class="form-group">
                                  <input type="text" id="received_by_email_post" class="form-control" placeholder="Received On By Email/Post" required>
                                </div>
                                <div class="form-group">
                                    
                                </div>
                                <div class="form-group">
                                    <input type="text" id="datepicker_9" name="document_dispatch_date" class="form-control" placeholder="Document Dispatch Date" required>
                                </div>
                                <div class="form-group">
                                   
                                    <input type="text" id="dispatched_by_email_post" name="dispatched_by_email_post" class="form-control" placeholder="Dispatched By Email/Post" required>
                               
                                </div>
                                <div class="form-group">
                                    <input type="text" id="foreign_characters" class="form-control" placeholder="Foreign Characters" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="disclaimer" class="form-control" placeholder="Disclaimer" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="specification" class="form-control" placeholder="Specification (Goods & Services)" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="datepicker_8" name="document_sent_by_client_date" class="form-control" placeholder="Document Sent By Client (Date)" required>
                                </div>
                              </div>
                              
                        <button type="button" class="btn btn-previous" id="previous_5">Previous</button> 
                        <button type="button" class="btn btn-next" id="next_6">Next</button>
                        </div>  
                    </fieldset>
                    <fieldset style="display:none;" id="box-7">
                     <div class="form-top">
                            <div class="form-top-left">
                                <h3><span><i class="fa fa-trademark" aria-hidden="true"></i>
</span> &nbsp Create Record</h3>
<p>all(<span class="required"></span>) fields are mandatory</p>  

                                                            </div>
                        </div>
                         <div class="form-bottom">
                            <div class="row">
                            <div class="form-group">
                                  <input type="text" id="transliteration" class="form-control" placeholder="Transliteration" required>
                                </div>
                                <div class="form-group">
                                    <input type="file" name="image">
                                </div>
                                <div class="form-group">
                                    <input type="text" id="vienna_code" class="form-control" placeholder="Vienna Code" required>
                                </div>

                                <div class="form-group" onChange="color_claim(this.value)">
                                    <select name="color_claim" class="form-control">
                                    <option>Color Claim</option>
                                    <option id="yes">Yes</option>
                                    <option id="no">No</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                   <textarea cols="5" rows="4" class="form-control" placeholder="Notes">
                                   </textarea>
                                </div>
                                
                              </div>
                              
                        <button type="button" class="btn btn-previous" id="previous_6">Previous</button> 
                        <button type="button" class="btn btn-next" id="next_7">Next</button>
                        </div>  
                    </fieldset>
                    </form>


</div>

                                   
            </div>
        </div>
    </div>